from __future__ import annotations

import json
from typing import Any

from app.agents.base import AnalysisAgent
from app.llm.prompts import HYPOTHESIS_PROMPT
from app.models.agent_outputs import Hypothesis, HypothesisSet


def build_evidence_catalog(state: dict[str, Any]) -> dict[str, str]:
    catalog: dict[str, str] = {}
    stats = state.get("statistical_analysis", {})
    target = stats.get("target") or state.get("data_profile", {}).get("potential_target")

    for index, item in enumerate(stats.get("important_correlations", []), start=1):
        feature_a = item.get("feature_a")
        feature_b = item.get("feature_b")
        corr = item.get("correlation")
        if feature_a is not None and feature_b is not None and isinstance(corr, (int, float)):
            evidence_id = f"E-CORR-{index}"
            catalog[evidence_id] = (
                f"Pearson correlation between {feature_a} and {feature_b}: {corr:.4f}."
            )

    for index, item in enumerate(stats.get("group_comparisons", []), start=1):
        group = item.get("group")
        average = item.get("avg")
        if group is not None and isinstance(average, (int, float)):
            evidence_id = f"E-GROUP-{index}"
            catalog[evidence_id] = f"Group {group}: average {target or 'measured metric'} is {average:.4f}."

    trends = stats.get("time_trends", [])
    for index, item in enumerate(trends, start=1):
        date = item.get("date")
        value = item.get("value")
        if date is not None and isinstance(value, (int, float)):
            evidence_id = f"E-TREND-{index}"
            trend_target = target or "measured metric"
            catalog[evidence_id] = f"Monthly {trend_target} at {date}: {value:.4f}."

    ml = state.get("ml_analysis", {})
    for index, item in enumerate(ml.get("important_features", []), start=1):
        feature = item.get("feature")
        importance = item.get("importance")
        if feature is not None and isinstance(importance, (int, float)):
            evidence_id = f"E-ML-{index}"
            catalog[evidence_id] = f"Predictive feature importance for {feature}: {importance:.4f}."

    for index, tool_result in enumerate(state.get("tool_results", []), start=1):
        evidence_id = f"E-TOOL-{index}"
        catalog[evidence_id] = json.dumps(tool_result, sort_keys=True, default=str)

    return catalog


class HypothesisGeneratorAgent(AnalysisAgent):
    name = "HypothesisGenerator"

    def execute(self, state: dict[str, Any]) -> dict[str, Any]:
        catalog = build_evidence_catalog(state)
        state["evidence_catalog"] = catalog
        if not catalog:
            state["hypotheses"] = []
            state["summary"] = "No metrics were available to support hypotheses."
            self.tools_used = ["build_evidence_catalog"]
            return state

        prompt = (
            f"Question: {state.get('user_question', '')}\n"
            f"Validated evidence catalog (cite IDs exactly): {json.dumps(catalog, ensure_ascii=False)}\n"
            f"Retrieved domain knowledge (cite source paths exactly): {state.get('rag_context', '')}\n"
            "Return 1 to 8 hypotheses. Each hypothesis must include id, statement, evidence_ids, "
            "domain_sources, confidence, and possible_counter_evidence."
        )
        response = self.request_structured(state, prompt, HypothesisSet, HYPOTHESIS_PROMPT)

        validated: list[Hypothesis] = []
        if isinstance(response, HypothesisSet):
            known_sources = {item["source"] for item in state.get("rag_sources", [])}
            for hypothesis in response.hypotheses:
                cited_ids = list(dict.fromkeys(item for item in hypothesis.evidence_ids if item in catalog))
                if cited_ids:
                    sources = list(
                        dict.fromkeys(item for item in hypothesis.domain_sources if item in known_sources)
                    )
                    if len(sources) != len(hypothesis.domain_sources):
                        self.record_error(
                            state,
                            f"Removed an unverified domain citation from hypothesis {hypothesis.id}.",
                        )
                    validated.append(
                        hypothesis.model_copy(update={"evidence_ids": cited_ids, "domain_sources": sources})
                    )
                else:
                    self.record_error(
                        state,
                        f"Discarded hypothesis {hypothesis.id}: it cited no IDs in the evidence catalog.",
                    )
        if not validated:
            validated = self._fallback_hypotheses(catalog)

        state["hypotheses"] = [
            {
                **item.model_dump(exclude={"evidence_ids"}),
                "evidence_ids": item.evidence_ids,
                "evidence": [catalog[evidence_id] for evidence_id in item.evidence_ids],
                "supporting_metrics": item.evidence_ids,
                "domain_sources": item.domain_sources,
            }
            for item in validated
        ]
        state["summary"] = f"Generated {len(validated)} hypotheses with verified evidence citations."
        self.tools_used = ["build_evidence_catalog", "ollama_structured_hypotheses"]
        return state

    @staticmethod
    def _fallback_hypotheses(catalog: dict[str, str]) -> list[Hypothesis]:
        evidence_id = next(iter(catalog))
        return [
            Hypothesis(
                id="H1",
                statement="The cited measured relationship is a candidate explanation to investigate, not evidence of causation.",
                evidence_ids=[evidence_id],
                confidence=0.5,
                possible_counter_evidence=["Association or predictive importance does not establish causation."],
            )
        ]
