from __future__ import annotations

import json
from typing import Any

import pandas as pd

from app.agents.base import AnalysisAgent
from app.llm.prompts import ML_PROMPT
from app.models.agent_outputs import AgentInterpretation
from app.tools.ml_tools import train_regression_model


class MLAnalystAgent(AnalysisAgent):
    name = "MLAnalyst"

    def execute(self, state: dict[str, Any]) -> dict[str, Any]:
        self.tools_used = ["train_regression_model"]
        df = pd.read_csv(state["cleaned_dataset_path"])
        target = state.get("data_profile", {}).get("potential_target") or "sales"
        numeric_columns = df.select_dtypes(include="number").columns.tolist()
        if target not in numeric_columns:
            target = numeric_columns[0] if numeric_columns else None
        if target is None or len(df) < 10:
            state["ml_analysis"] = {
                "problem_type": "not_applicable",
                "target": target,
                "models": [],
                "important_features": [],
                "summary": "Machine learning was skipped because a numeric target or sufficient rows were unavailable.",
            }
            state["ml_interpretation"] = {
                "summary": state["ml_analysis"]["summary"],
                "insights": [],
                "limitations": ["A numeric target and at least ten rows are required for this model."],
            }
            state["summary"] = state["ml_analysis"]["summary"]
            return state
        feature_columns = [col for col in numeric_columns if col != target]
        if not feature_columns:
            state["ml_analysis"] = {
                "problem_type": "not_applicable",
                "target": target,
                "models": [],
                "important_features": [],
                "summary": "Machine learning was skipped because no numeric predictor features were available.",
            }
            state["ml_interpretation"] = {
                "summary": state["ml_analysis"]["summary"],
                "insights": [],
                "limitations": ["A supervised model could not be evaluated without predictor columns."],
            }
            state["summary"] = state["ml_analysis"]["summary"]
            return state
        analysis_result = self.call_mcp_tool(
            state,
            "ml",
            "train_regression_model",
            {
                "dataset_path": state["cleaned_dataset_path"],
                "target": target,
                "features": feature_columns,
            },
            fallback=lambda: train_regression_model(df, target, feature_columns),
        )
        if "models" in analysis_result:
            analysis = analysis_result
        else:
            importance = analysis_result.get("feature_importance", {})
            analysis = {
                "problem_type": "regression",
                "target": target,
                "models": [
                    {
                        "name": analysis_result.get("model", "Regression model"),
                        "r2": analysis_result.get("r2"),
                        "rmse": analysis_result.get("rmse"),
                    }
                ],
                "important_features": [
                    {"feature": feature, "importance": value}
                    for feature, value in sorted(
                        importance.items(), key=lambda item: item[1], reverse=True
                    )
                ],
                "summary": (
                    f"Evaluated {analysis_result.get('model', 'regression model')} for {target} "
                    f"on {analysis_result.get('test_rows', 0)} holdout rows."
                ),
                "causal_warning": analysis_result.get("causal_warning", ""),
            }
        state["ml_analysis"] = analysis
        state["summary"] = analysis.get("summary", "Machine-learning analysis completed.")
        interpretation = self.request_structured(
            state,
            (
                f"Question: {state.get('user_question', '')}\n"
                f"Computed model evaluation: {json.dumps(analysis, default=str)}"
            ),
            AgentInterpretation,
            ML_PROMPT,
        )
        state["ml_interpretation"] = (
            interpretation.model_dump()
            if isinstance(interpretation, AgentInterpretation)
            else {
                "summary": analysis.get("summary", "A model was trained and evaluated."),
                "insights": [],
                "limitations": ["Predictive feature importance is not evidence of causation."],
            }
        )
        return state
