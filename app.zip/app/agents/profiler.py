from __future__ import annotations

from typing import Any
import json

from app.agents.base import AnalysisAgent
from app.llm.prompts import PROFILE_PROMPT
from app.models.agent_outputs import AgentInterpretation
from app.tools.profiling_tools import profile_dataset


class DataProfilerAgent(AnalysisAgent):
    name = "DataProfiler"

    def execute(self, state: dict[str, Any]) -> dict[str, Any]:
        self.tools_used = ["profile_dataset"]
        profile = profile_dataset(state["dataset_path"])
        state["data_profile"] = profile
        state["summary"] = profile.get("summary", "")
        interpretation = self.request_structured(
            state,
            f"Question: {state.get('user_question', '')}\nComputed profile: {json.dumps(profile, default=str)}",
            AgentInterpretation,
            PROFILE_PROMPT,
        )
        state["profile_interpretation"] = (
            interpretation.model_dump()
            if isinstance(interpretation, AgentInterpretation)
            else {
                "summary": profile.get("summary", "Profile generated from the uploaded dataset."),
                "insights": [],
                "limitations": ["Profile metrics are descriptive and depend on the uploaded data quality."],
            }
        )
        return state
