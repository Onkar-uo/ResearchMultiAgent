"""Agent implementations."""
