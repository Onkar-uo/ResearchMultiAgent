from __future__ import annotations

import time
from datetime import datetime, timezone
from typing import Any
from pydantic import BaseModel

from app.config import MAX_ANALYSIS_ITERATIONS
from app.llm.ollama_client import get_ollama_client
from app.models.database import DatabaseManager


class AnalysisAgent:
    name = "BaseAgent"

    def __init__(self, llm_client: Any | None = None) -> None:
        self.llm = llm_client or get_ollama_client()
        self.db = DatabaseManager()

    def run(self, state: dict[str, Any]) -> dict[str, Any]:
        state.setdefault("errors", [])
        state.setdefault("execution_trace", [])
        state.setdefault("iteration", 0)
        state.setdefault("max_iterations", MAX_ANALYSIS_ITERATIONS)
        started_at = datetime.now(timezone.utc)
        start = time.time()
        errors_before = len(state["errors"])
        try:
            result = self.execute(state)
            status = "complete"
            output_summary = (
                (result.get("summary") or f"{self.name} completed.")
                if isinstance(result, dict)
                else str(result)
            )
            errors = [
                item["error"]
                for item in state["errors"][errors_before:]
                if item.get("agent") == self.name
            ]
            if errors:
                status = "completed_with_warnings"
        except Exception as exc:  # pragma: no cover
            result = state
            status = "error"
            output_summary = str(exc)
            errors = [str(exc)]
            self.record_error(state, str(exc))
        duration = round(time.time() - start, 3)
        ended_at = datetime.now(timezone.utc)

        state["execution_trace"].append({
            "agent_name": self.name,
            "status": status,
            "duration": duration,
            "tools_used": getattr(self, "tools_used", []) or [],
            "output_summary": output_summary,
            "errors": errors,
            "iteration": state.get("iteration", 0),
            "timestamp": ended_at.isoformat(),
        })

        self.db.log_execution(
            session_id=state.get("session_id", "anonymous"),
            agent_name=self.name,
            start_time=started_at.isoformat(),
            end_time=ended_at.isoformat(),
            duration=duration,
            status=status,
            output_summary=output_summary,
            tools_used=getattr(self, "tools_used", []) or [],
            errors=errors,
            iteration=state.get("iteration", 0),
            raw_payload={
                "agent_name": self.name,
                "summary": output_summary,
                "status": status,
            },
        )
        return result if isinstance(result, dict) else state

    def execute(self, state: dict[str, Any]) -> dict[str, Any]:
        return state

    def request_structured(
        self,
        state: dict[str, Any],
        prompt: str,
        output_model: type[BaseModel],
        system_prompt: str,
    ) -> BaseModel | None:
        try:
            return self.llm.generate_structured(prompt, output_model, system_prompt)
        except Exception as exc:
            self.record_error(state, f"Structured LLM response unavailable: {exc}")
            return None

    def record_error(self, state: dict[str, Any], message: str) -> None:
        state.setdefault("errors", []).append(
            {
                "agent": self.name,
                "error": message,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        )

    def call_mcp_tool(
        self,
        state: dict[str, Any],
        server_name: str,
        tool_name: str,
        arguments: dict[str, Any],
        fallback: Any = None,
    ) -> Any:
        from app.mcp.client import MCPClient

        result, record = MCPClient().call_tool(
            server_name,
            tool_name,
            arguments,
            fallback=fallback,
        )
        record["agent"] = self.name
        record["iteration"] = state.get("iteration", 0)
        state.setdefault("mcp_tool_calls", []).append(record)
        state.setdefault("mcp_results", []).append(
            {
                "server": server_name,
                "tool": tool_name,
                "result": result,
                "status": record["status"],
            }
        )
        state.setdefault("mcp_server_status", {})[server_name] = {
            "status": record["status"],
            "error": record.get("error"),
            "fallback": record.get("fallback"),
        }
        if record["status"] == "fallback":
            self.record_error(
                state,
                f"MCP server '{server_name}' unavailable; used local Python fallback for '{tool_name}'.",
            )
        return result
