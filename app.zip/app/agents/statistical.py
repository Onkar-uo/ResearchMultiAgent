from __future__ import annotations

import json
from typing import Any, Callable

import pandas as pd

from app.agents.base import AnalysisAgent
from app.llm.prompts import STATISTICS_PROMPT
from app.mcp.local_fallbacks import run_data_science_fallback
from app.models.agent_outputs import AgentInterpretation
from app.tools.statistics_tools import calculate_correlations, group_analysis, time_trend_analysis


class StatisticalAnalystAgent(AnalysisAgent):
    name = "StatisticalAnalyst"

    def execute(self, state: dict[str, Any]) -> dict[str, Any]:
        self.tools_used = ["calculate_correlations", "group_analysis", "time_trend_analysis"]
        df = pd.read_csv(state["cleaned_dataset_path"])
        target = state.get("data_profile", {}).get("potential_target")
        if target not in df.select_dtypes(include="number").columns:
            target = next(iter(df.select_dtypes(include="number").columns), None)
        correlation = calculate_correlations(df, target)
        group_results = []
        if target is not None:
            for group_col in ["region", "product"]:
                if group_col in df.columns:
                    group_results.extend(group_analysis(df, group_col, target))
        time_results = []
        date_col = next(
            (column for column in df.columns if column in state.get("data_profile", {}).get("datetime_columns", [])),
            None,
        )
        if date_col is not None and target is not None:
            time_results = time_trend_analysis(df, date_col, target)

        analysis = {
            "target": target,
            "important_correlations": correlation.get("pearson_top", []),
            "group_comparisons": group_results,
            "time_trends": time_results,
            "additional_tool_results": state.get("tool_results", []),
            "statistical_findings": [
                {"metric": "sales_corr", "description": "Top correlation relationships in cleaned data", "value": correlation.get("pearson_top", [])[:3]},
                {"metric": "group_metrics", "description": "Average values by group", "value": group_results[:3]},
                {"metric": "time_trend", "description": "Monthly trend", "value": time_results[:3]},
            ],
        }
        mcp_statistics = []
        numeric_columns = df.select_dtypes(include="number").columns.tolist()
        dataset_path = state["cleaned_dataset_path"]

        def run_statistical_tool(
            tool_name: str,
            arguments: dict[str, Any],
            fallback: Callable[[], Any],
        ) -> Any | None:
            try:
                return self.call_mcp_tool(
                    state,
                    "data_science",
                    tool_name,
                    arguments,
                    fallback=fallback,
                )
            except Exception as exc:
                self.record_error(state, f"Statistical MCP tool '{tool_name}' failed: {exc}")
                return None

        if target and numeric_columns:
            predictor = next((column for column in numeric_columns if column != target), None)
            if predictor:
                result = run_statistical_tool(
                    "calculate_correlation",
                    {
                        "dataset_path": dataset_path,
                        "column_a": target,
                        "column_b": predictor,
                        "method": "pearson",
                    },
                    lambda: run_data_science_fallback(
                        "calculate_correlation",
                        {"column_a": target, "column_b": predictor, "method": "pearson"},
                        dataset_path,
                    ),
                )
                if result is not None:
                    mcp_statistics.append(result)
        if target and state.get("data_profile", {}).get("categorical_columns"):
            group_column = next(
                (
                    column
                    for column in state["data_profile"]["categorical_columns"]
                    if column in df.columns
                ),
                None,
            )
            if group_column:
                result = run_statistical_tool(
                    "group_analysis",
                    {
                        "dataset_path": dataset_path,
                        "group_column": group_column,
                        "value_column": target,
                    },
                    lambda: run_data_science_fallback(
                        "group_analysis",
                        {"group_column": group_column, "value_column": target},
                        dataset_path,
                    ),
                )
                if result is not None:
                    mcp_statistics.append(result)
        if target and date_col:
            result = run_statistical_tool(
                "analyze_time_series",
                {
                    "dataset_path": dataset_path,
                    "date_column": date_col,
                    "value_column": target,
                },
                lambda: run_data_science_fallback(
                    "analyze_time_series",
                    {"date_column": date_col, "value_column": target},
                    dataset_path,
                ),
            )
            if result is not None:
                mcp_statistics.append(result)
        analysis["mcp_statistics"] = mcp_statistics
        analysis["additional_tool_results"] = [
            *analysis["additional_tool_results"],
            *mcp_statistics,
        ]
        state["statistical_analysis"] = analysis
        state["summary"] = (
            f"Computed {len(analysis['important_correlations'])} correlations, "
            f"{len(group_results)} group summaries and {len(time_results)} time periods."
        )
        interpretation = self.request_structured(
            state,
            (
                f"Question: {state.get('user_question', '')}\n"
                f"Computed statistical results: {json.dumps(analysis, default=str)}"
            ),
            AgentInterpretation,
            STATISTICS_PROMPT,
        )
        state["statistical_interpretation"] = (
            interpretation.model_dump()
            if isinstance(interpretation, AgentInterpretation)
            else {
                "summary": "Statistical summaries and correlations were calculated deterministically.",
                "insights": [],
                "limitations": ["Correlations and group means do not establish causation."],
            }
        )
        return state
