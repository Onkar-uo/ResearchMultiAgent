from __future__ import annotations

import json
from typing import Any

from app.agents.base import AnalysisAgent
from app.config import RAG_TOP_K
from app.mcp.local_fallbacks import run_knowledge_fallback


class KnowledgeAgent(AnalysisAgent):
    name = "KnowledgeAgent"

    def execute(self, state: dict[str, Any]) -> dict[str, Any]:
        profile = state.get("data_profile", {})
        statistics = state.get("statistical_analysis", {})
        query = "\n".join(
            part
            for part in (
                f"Question: {state.get('user_question', '')}",
                f"Columns: {', '.join(profile.get('column_names', []))}",
                f"Statistical evidence: {json.dumps(statistics, ensure_ascii=False, default=str)[:3000]}",
                f"Model evidence: {json.dumps(state.get('ml_analysis', {}), ensure_ascii=False, default=str)[:1500]}",
                f"Current hypotheses: {json.dumps(state.get('hypotheses', []), ensure_ascii=False)[:2000]}",
                f"Critic questions: {', '.join(state.get('critic_review', {}).get('missing_evidence', []))}",
            )
            if part
        )
        state.setdefault("knowledge_queries", []).append(
            {"query": query, "iteration": state.get("iteration", 0)}
        )
        self.tools_used = ["search_knowledge"]
        try:
            result = self.call_mcp_tool(
                state,
                "knowledge",
                "search_knowledge",
                {"query": query, "top_k": RAG_TOP_K},
                fallback=lambda: run_knowledge_fallback(query, RAG_TOP_K),
            )
        except Exception as exc:
            self.record_error(state, f"Local knowledge retrieval failed: {exc}")
            state["rag_sources"] = []
            state["rag_context"] = ""
            state["summary"] = "No knowledge context was available."
            return state

        sources = result.get("results", []) if isinstance(result, dict) else []
        if not isinstance(sources, list):
            self.record_error(state, "Knowledge search returned an invalid result shape.")
            sources = []
        state["rag_sources"] = [
            {
                "source": item["source"],
                "score": item.get("score"),
                "content": item["content"],
                "metadata": item.get("metadata", {}),
            }
            for item in sources
            if isinstance(item, dict)
            and isinstance(item.get("source"), str)
            and isinstance(item.get("content"), str)
        ]
        state["rag_context"] = "\n\n".join(
            f"[{item['source']}]\n{item['content']}" for item in state["rag_sources"]
        )
        state["summary"] = f"Retrieved {len(state['rag_sources'])} local knowledge source chunk(s)."
        return state
