from __future__ import annotations

import json
from typing import Any

from app.agents.base import AnalysisAgent
from app.llm.prompts import CRITIC_PROMPT
from app.models.agent_outputs import CriticReview


class CriticAgent(AnalysisAgent):
    name = "Critic"

    def execute(self, state: dict[str, Any]) -> dict[str, Any]:
        hypotheses = state.get("hypotheses", [])
        catalog = state.get("evidence_catalog", {})
        if not hypotheses:
            review = CriticReview(
                overall_status="INSUFFICIENT_EVIDENCE",
                missing_evidence=["No hypotheses were supported by available metrics."],
                required_additional_analysis=["Collect or compute relevant evidence before drawing conclusions."],
                confidence=0.1,
            )
        else:
            prompt = (
                f"Question: {state.get('user_question', '')}\n"
                f"Hypotheses: {json.dumps(hypotheses, ensure_ascii=False)}\n"
                f"Evidence catalog: {json.dumps(catalog, ensure_ascii=False)}\n"
                f"Retrieved domain sources: {json.dumps(state.get('rag_sources', []), ensure_ascii=False)}\n"
                "Review every hypothesis ID. Each hypothesis_reviews entry must include id and accepted. "
                "Use REVISE for a concrete gap that available analysis can address."
            )
            response = self.request_structured(state, prompt, CriticReview, CRITIC_PROMPT)
            known_ids = {item.get("id") for item in hypotheses}
            validated_reviews = []
            if isinstance(response, CriticReview):
                validated_reviews = [
                    item
                    for item in response.hypothesis_reviews
                    if item.get("id") in known_ids and isinstance(item.get("accepted"), bool)
                ]
                reviewed_ids = {item["id"] for item in validated_reviews}
                if reviewed_ids == known_ids:
                    review = response
                    review.hypothesis_reviews = validated_reviews
                    if review.overall_status == "PASS" and any(
                        not item["accepted"] for item in validated_reviews
                    ):
                        review.overall_status = "REVISE"
                        review.missing_evidence.append(
                            "At least one hypothesis was explicitly marked unsupported."
                        )
                        if not review.required_additional_analysis:
                            review.required_additional_analysis.append(
                                "Revisit the evidence cited by unsupported hypotheses."
                            )
                else:
                    self.record_error(
                        state,
                        "Critic response did not provide a valid review for every hypothesis; deterministic review used.",
                    )
                    review = self._fallback_review(hypotheses)
            else:
                review = self._fallback_review(hypotheses)

        state["critic_review"] = review.model_dump()
        state["summary"] = f"Critic status: {review.overall_status}."
        self.tools_used = ["validate_hypothesis_citations", "ollama_structured_critic_review"]
        return state

    @staticmethod
    def _fallback_review(hypotheses: list[dict[str, Any]]) -> CriticReview:
        supported = [item for item in hypotheses if item.get("evidence_ids")]
        if len(supported) != len(hypotheses):
            status = "INSUFFICIENT_EVIDENCE"
        else:
            status = "PASS"
        return CriticReview(
            overall_status=status,
            hypothesis_reviews=[
                {"id": item.get("id", "unknown"), "accepted": bool(item.get("evidence_ids"))}
                for item in hypotheses
            ],
            missing_evidence=[] if status == "PASS" else ["At least one hypothesis lacks a valid evidence citation."],
            contradictions=[],
            required_additional_analysis=[] if status == "PASS" else ["Collect more relevant measured evidence."],
            confidence=0.5 if status == "PASS" else 0.1,
        )
