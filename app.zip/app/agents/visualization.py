from __future__ import annotations

import json
from typing import Any

import pandas as pd

from app.agents.base import AnalysisAgent
from app.llm.prompts import VISUALIZATION_PROMPT
from app.models.agent_outputs import AgentInterpretation
from app.tools.visualization_tools import generate_bar_plot, generate_correlation_heatmap, generate_time_series_plot


class VisualizationAgent(AnalysisAgent):
    name = "VisualizationAgent"

    def execute(self, state: dict[str, Any]) -> dict[str, Any]:
        self.tools_used = []
        df = pd.read_csv(state["cleaned_dataset_path"])
        session_id = state["session_id"]
        profile = state.get("data_profile", {})
        numeric_columns = df.select_dtypes(include="number").columns.tolist()
        target = profile.get("potential_target")
        if target not in numeric_columns:
            target = numeric_columns[0] if numeric_columns else None
        date_column = next(
            (column for column in profile.get("datetime_columns", []) if column in df.columns),
            None,
        )
        group_column = next(
            (column for column in profile.get("categorical_columns", []) if column in df.columns),
            None,
        )
        plan = []
        if date_column and target:
            plan.append(
                (
                    "generate_time_series_plot",
                    {"dataset_path": state["cleaned_dataset_path"], "date_column": date_column, "value_column": target, "session_id": session_id},
                    lambda: generate_time_series_plot(df, date_column, target, session_id),
                )
            )
        if group_column and target:
            plan.append(
                (
                    "generate_group_comparison_plot",
                    {"dataset_path": state["cleaned_dataset_path"], "group_column": group_column, "value_column": target, "session_id": session_id},
                    lambda: generate_bar_plot(df, group_column, target, session_id),
                )
            )
        if numeric_columns:
            plan.append(
                (
                    "generate_correlation_heatmap",
                    {"dataset_path": state["cleaned_dataset_path"], "session_id": session_id},
                    lambda: generate_correlation_heatmap(df, session_id),
                )
            )
        visuals = []
        for tool_name, arguments, fallback in plan:
            try:
                result = self.call_mcp_tool(
                    state,
                    "visualization",
                    tool_name,
                    arguments,
                    fallback=fallback,
                )
            except Exception as exc:
                self.record_error(state, f"Visualization tool '{tool_name}' failed: {exc}")
                continue
            self.tools_used.append(tool_name)
            visuals.append(
                {
                    "type": tool_name,
                    "path": result.get("path", ""),
                    "title": result.get("title", tool_name.replace("_", " ").title()),
                }
            )
        interpretation = self.request_structured(
            state,
            (
                f"Question: {state.get('user_question', '')}\n"
                f"Statistical results: {json.dumps(state.get('statistical_analysis', {}), default=str)}\n"
                f"Plots generated: {json.dumps(visuals, default=str)}"
            ),
            AgentInterpretation,
            VISUALIZATION_PROMPT,
        )
        if isinstance(interpretation, AgentInterpretation):
            for index, visual in enumerate(visuals):
                if index < len(interpretation.insights):
                    visual["reason"] = interpretation.insights[index]
        else:
            for visual in visuals:
                visual["reason"] = "Selected to visualize the available fields and computed relationships."
        state["visualizations"] = visuals
        state["summary"] = f"Generated {len(visuals)} visualization(s)."
        return state
