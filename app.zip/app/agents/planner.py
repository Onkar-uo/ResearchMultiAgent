from __future__ import annotations

import json
from typing import Any

from app.agents.base import AnalysisAgent
from app.config import MCP_ENABLED
from app.mcp.catalog import tool_schema_for
from app.mcp.local_fallbacks import run_data_science_fallback
from app.mcp.registry import list_langchain_tool_schemas
from app.llm.prompts import ANALYSIS_PLANNER_PROMPT


class AnalysisPlannerAgent(AnalysisAgent):
    name = "AnalysisPlanner"

    def execute(self, state: dict[str, Any]) -> dict[str, Any]:
        self.tools_used = []
        profile = state.get("data_profile", {})
        messages = [
            {
                "role": "system",
                "content": ANALYSIS_PLANNER_PROMPT,
            },
            {
                "role": "user",
                "content": json.dumps(
                    {
                        "question": state["user_question"],
                        "additional_analysis_requested": state.get("critic_review", {}).get(
                            "required_additional_analysis", []
                        ),
                        "profile": {
                            "numerical_columns": profile.get("numerical_columns", []),
                            "categorical_columns": profile.get("categorical_columns", []),
                            "datetime_columns": profile.get("datetime_columns", []),
                            "potential_target": profile.get("potential_target"),
                        },
                        "instruction": "Select up to three useful predefined tools. Do not request unavailable columns.",
                    }
                ),
            },
        ]
        try:
            available_tools = (
                list_langchain_tool_schemas("data_science")
                if MCP_ENABLED
                else tool_schema_for("data_science")
            )
        except Exception as exc:
            self.record_error(state, f"MCP tool discovery failed; using the registered local tool catalog: {exc}")
            available_tools = tool_schema_for("data_science")

        try:
            tool_calls = self.llm.call_tools(messages, available_tools)
        except Exception as exc:
            self.record_error(state, f"LLM tool selection failed; deterministic tool selection used: {exc}")
            tool_calls = []

        dataset_path = state["cleaned_dataset_path"]
        results: list[dict[str, Any]] = []
        for tool_call in tool_calls[:3]:
            function_call = tool_call.get("function", {})
            name = function_call.get("name")
            arguments = function_call.get("arguments", {})
            if isinstance(arguments, str):
                try:
                    arguments = json.loads(arguments)
                except json.JSONDecodeError:
                    arguments = None
            if not isinstance(name, str) or not isinstance(arguments, dict):
                self.record_error(state, "Ollama returned a malformed function tool call.")
                continue
            schema_names = {item["function"]["name"] for item in available_tools}
            if name not in schema_names:
                self.record_error(state, f"Ollama requested unregistered MCP tool '{name}'.")
                continue
            arguments["dataset_path"] = dataset_path
            try:
                result = self.call_mcp_tool(
                    state,
                    "data_science",
                    name,
                    arguments,
                    fallback=lambda tool_name=name, tool_args=arguments: run_data_science_fallback(
                        tool_name, tool_args, dataset_path
                    ),
                )
            except Exception as exc:
                self.record_error(state, f"Analysis tool '{name}' failed: {exc}")
                continue
            results.append(result)
            self.tools_used.append(name)

        if not results:
            if not tool_calls:
                self.record_error(
                    state,
                    "Ollama selected no tools; a deterministic plan was used instead.",
                )
            results = self._run_deterministic_plan(state, profile, dataset_path)

        state.setdefault("tool_results", []).extend(results)
        state["summary"] = (
            f"Executed {len(results)} validated Python analysis tool(s); "
            f"{sum(call['status'] == 'success' for call in state.get('mcp_tool_calls', []))} via MCP."
        )
        return state

    def _run_deterministic_plan(
        self,
        state: dict[str, Any],
        profile: dict[str, Any],
        dataset_path: str,
    ) -> list[dict[str, Any]]:
        numeric = profile.get("numerical_columns", [])
        categories = profile.get("categorical_columns", [])
        dates = profile.get("datetime_columns", [])
        target = profile.get("potential_target")
        if target not in numeric:
            target = numeric[0] if numeric else None

        plan: list[tuple[str, dict[str, Any]]] = []
        if target and len(numeric) > 1:
            predictor = next((column for column in numeric if column != target), None)
            if predictor:
                plan.append(
                    (
                        "calculate_correlation",
                        {"column_a": target, "column_b": predictor, "method": "pearson"},
                    )
                )
        if target and categories:
            plan.append(
                (
                    "group_analysis",
                    {"group_column": categories[0], "value_column": target},
                )
            )
        if target and dates:
            plan.append(
                (
                    "analyze_time_series",
                    {"date_column": dates[0], "value_column": target},
                )
            )
        if not plan and target:
            plan.append(("get_column_statistics", {"column": target}))
        if not plan:
            plan.append(("profile_dataset", {}))

        results = []
        for name, arguments in plan[:3]:
            arguments["dataset_path"] = dataset_path
            try:
                result = self.call_mcp_tool(
                    state,
                    "data_science",
                    name,
                    arguments,
                    fallback=lambda tool_name=name, tool_args=arguments: run_data_science_fallback(
                        tool_name, tool_args, dataset_path
                    ),
                )
            except Exception as exc:
                self.record_error(state, f"Deterministic tool '{name}' failed: {exc}")
                continue
            self.tools_used.append(name)
            results.append(result)
        return results
