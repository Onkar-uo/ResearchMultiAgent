from __future__ import annotations

import json
from typing import Any

from app.agents.base import AnalysisAgent
from app.llm.prompts import CLEANING_PROMPT
from app.models.agent_outputs import AgentInterpretation
from app.tools.cleaning_tools import clean_dataset


class DataCleaningAgent(AnalysisAgent):
    name = "DataCleaning"

    def execute(self, state: dict[str, Any]) -> dict[str, Any]:
        self.tools_used = ["clean_dataset"]
        profile = state.get("data_profile") or {}
        operations = ["duplicates", "missing_values", "datetime", "outliers"]
        if profile.get("potential_target"):
            operations.append("outliers")
        report = clean_dataset(state["dataset_path"], operations=operations)
        state["cleaning_report"] = report
        state["cleaned_dataset_path"] = report.get("cleaned_dataset_path", state["dataset_path"])
        state["summary"] = report.get("notes", "Dataset cleaning completed.")
        interpretation = self.request_structured(
            state,
            (
                f"Question: {state.get('user_question', '')}\n"
                f"Profile: {json.dumps(profile, default=str)}\n"
                f"Executed transformations: {json.dumps(report, default=str)}"
            ),
            AgentInterpretation,
            CLEANING_PROMPT,
        )
        state["cleaning_interpretation"] = (
            interpretation.model_dump()
            if isinstance(interpretation, AgentInterpretation)
            else {
                "summary": report.get("notes", "Dataset transformations completed."),
                "insights": report.get("transformations", []),
                "limitations": ["Outliers were detected but not removed automatically."],
            }
        )
        return state
