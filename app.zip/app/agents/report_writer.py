from __future__ import annotations

import json
from typing import Any

from app.agents.base import AnalysisAgent
from app.llm.prompts import REPORT_PROMPT
from app.models.agent_outputs import ReportFinding, ReportSections


class ReportWriterAgent(AnalysisAgent):
    name = "ReportWriter"

    def execute(self, state: dict[str, Any]) -> dict[str, Any]:
        catalog = state.get("evidence_catalog", {})
        report_input = {
            "question": state.get("user_question", ""),
            "profile": state.get("data_profile", {}),
            "profile_interpretation": state.get("profile_interpretation", {}),
            "cleaning_report": state.get("cleaning_report", {}),
            "statistical_analysis": state.get("statistical_analysis", {}),
            "statistical_interpretation": state.get("statistical_interpretation", {}),
            "ml_analysis": state.get("ml_analysis", {}),
            "ml_interpretation": state.get("ml_interpretation", {}),
            "hypotheses": state.get("hypotheses", []),
            "critic_review": state.get("critic_review", {}),
            "evidence_catalog": catalog,
            "domain_sources": state.get("rag_sources", []),
        }
        response = self.request_structured(
            state,
            f"Validated analysis data:\n{json.dumps(report_input, ensure_ascii=False, default=str)}",
            ReportSections,
            REPORT_PROMPT,
        )

        sections = response if isinstance(response, ReportSections) else self._fallback_sections(state)
        valid_findings: list[ReportFinding] = []
        known_sources = {item["source"] for item in state.get("rag_sources", [])}
        for finding in sections.key_findings:
            valid_ids = list(dict.fromkeys(item for item in finding.evidence_ids if item in catalog))
            if valid_ids:
                valid_sources = list(
                    dict.fromkeys(item for item in finding.domain_sources if item in known_sources)
                )
                if len(valid_sources) != len(finding.domain_sources):
                    self.record_error(state, "Removed an unverified domain citation from a report finding.")
                valid_findings.append(
                    finding.model_copy(update={"evidence_ids": valid_ids, "domain_sources": valid_sources})
                )
            else:
                self.record_error(state, "Discarded a report finding without a valid evidence citation.")

        all_citations = set(catalog)
        summary = sections.executive_summary
        cited_ids = [evidence_id for evidence_id in all_citations if evidence_id in summary]
        if not cited_ids:
            sections = self._fallback_sections(state)
            summary = sections.executive_summary
            valid_findings = sections.key_findings
        else:
            sections.executive_summary = summary
            sections.key_findings = valid_findings

        state["report_sections"] = sections.model_dump()
        state["final_report"] = self._render_report(state, sections, catalog)
        state["summary"] = "Final report generated with validated data and domain citations."
        self.tools_used = ["validate_report_citations", "ollama_structured_report"]
        return state

    @staticmethod
    def _fallback_sections(state: dict[str, Any]) -> ReportSections:
        catalog = state.get("evidence_catalog", {})
        hypotheses = state.get("hypotheses", [])
        critic = state.get("critic_review", {})
        if hypotheses and catalog:
            first_hypothesis = hypotheses[0]
            evidence_id = next(
                (item for item in first_hypothesis.get("evidence_ids", []) if item in catalog),
                next(iter(catalog)),
            )
            summary = (
                f"The analysis found a candidate explanation for “{state.get('user_question', 'the question')},” "
                f"cited as [{evidence_id}]. This evidence is exploratory and does not establish causation."
            )
            findings = [
                ReportFinding(
                    statement=item.get("statement", "Validated hypothesis"),
                    evidence_ids=[evidence_id_value for evidence_id_value in item.get("evidence_ids", []) if evidence_id_value in catalog]
                    or [evidence_id],
                    domain_sources=[
                        source
                        for source in item.get("domain_sources", [])
                        if source in {entry["source"] for entry in state.get("rag_sources", [])}
                    ],
                )
                for item in hypotheses[:8]
            ]
        else:
            summary = (
                "The available analysis did not produce sufficient validated evidence to answer the question "
                "conclusively. No causal conclusion should be drawn."
            )
            findings = []
        limitations = [
            "Observed correlations and predictive feature importance do not establish causation.",
            "Data quality and missingness may affect the results.",
        ]
        if critic.get("overall_status") == "INSUFFICIENT_EVIDENCE":
            limitations.append("The critic found the available evidence insufficient for a stronger conclusion.")
        return ReportSections(
            executive_summary=summary,
            key_findings=findings,
            limitations=limitations,
        )

    @staticmethod
    def _render_report(
        state: dict[str, Any],
        sections: ReportSections,
        evidence_catalog: dict[str, str],
    ) -> str:
        profile = state.get("data_profile", {})
        cleaning = state.get("cleaning_report", {})
        ml = state.get("ml_analysis", {})
        critic = state.get("critic_review", {})
        visualizations = state.get("visualizations", [])
        domain_sources = state.get("rag_sources", [])

        lines = [
            "# Executive Summary",
            sections.executive_summary,
        ]
        summary_evidence_ids = [
            evidence_id for evidence_id in evidence_catalog if f"[{evidence_id}]" in sections.executive_summary
        ]
        for evidence_id in summary_evidence_ids:
            lines.append(f"> [{evidence_id}] {evidence_catalog[evidence_id]}")
        lines.extend(
            [
                "",
                "## Dataset Overview",
                f"- Rows: {profile.get('row_count', 'unknown')}",
                f"- Columns: {profile.get('column_count', 'unknown')}",
                f"- Important variables: {', '.join(profile.get('important_columns', [])) or 'not identified'}",
                f"- Duplicate rows removed: {cleaning.get('removed_duplicates', 0)}",
                f"- Missing values handled: {cleaning.get('missing_values_handled', 0)}",
                f"- Missing values remaining after cleaning: {cleaning.get('missing_values_remaining', 0)}",
                f"- Cleaning: {cleaning.get('notes', 'No cleaning summary available.')}",
                "",
                "## Key Findings",
            ]
        )
        if sections.key_findings:
            for finding in sections.key_findings:
                citations = [f"[{item}]" for item in finding.evidence_ids]
                citations.extend(f"[Domain: {source}]" for source in finding.domain_sources)
                lines.append(f"- {finding.statement} ({', '.join(citations)})")
                for evidence_id in finding.evidence_ids:
                    lines.append(f"  - {evidence_catalog[evidence_id]}")
        else:
            lines.append("- No findings with verified evidence citations are available.")

        lines.extend(["", "## Model Results"])
        if ml.get("models"):
            for model in ml["models"]:
                lines.append(
                    f"- {model.get('name', 'Model')}: R²={model.get('r2')}, RMSE={model.get('rmse')}"
                )
        else:
            lines.append("- Machine-learning metrics were not available.")

        lines.extend(["", "## Domain Knowledge Sources"])
        if domain_sources:
            for item in domain_sources:
                lines.append(
                    f"- `{item['source']}` (similarity {item.get('score', 'not available')})"
                )
        else:
            lines.append("- No local domain-knowledge sources were retrieved.")

        lines.extend(["", "## Visual Evidence"])
        for visual in visualizations:
            lines.append(
                f"- {visual.get('title', visual.get('type', 'Chart'))}: {visual.get('reason', 'Generated from available data.')}"
            )

        lines.extend(["", "## Limitations"])
        for limitation in sections.limitations:
            lines.append(f"- {limitation}")
        lines.extend(
            [
                "- Model performance and feature importance are predictive evidence, not causal estimates.",
                f"- Critic review status: {critic.get('overall_status', 'not available')}.",
                "",
                "## Final Conclusion",
                sections.executive_summary,
            ]
        )
        return "\n".join(lines)
