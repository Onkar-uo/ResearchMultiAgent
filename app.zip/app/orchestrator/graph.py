from __future__ import annotations

from typing import Any

from langgraph.graph import END, START, StateGraph

from app.agents.cleaner import DataCleaningAgent
from app.agents.critic import CriticAgent
from app.agents.hypothesis import HypothesisGeneratorAgent
from app.agents.knowledge import KnowledgeAgent
from app.agents.ml import MLAnalystAgent
from app.agents.planner import AnalysisPlannerAgent
from app.agents.profiler import DataProfilerAgent
from app.agents.report_writer import ReportWriterAgent
from app.agents.statistical import StatisticalAnalystAgent
from app.agents.visualization import VisualizationAgent
from app.llm.ollama_client import get_ollama_client
from app.orchestrator.state import AnalysisState


def enforce_iteration_limit(state: AnalysisState) -> dict[str, Any]:
    review = dict(state.get("critic_review", {}))
    iteration = state.get("iteration", 0)
    max_iterations = state.get("max_iterations", 3)
    if review.get("overall_status") == "REVISE":
        if iteration >= max_iterations:
            review["overall_status"] = "INSUFFICIENT_EVIDENCE"
            review.setdefault("missing_evidence", []).append(
                f"Maximum analysis revision count ({max_iterations}) reached."
            )
            return {"critic_review": review}
        return {"iteration": iteration + 1}
    return {}


def route_critic(state: AnalysisState) -> str:
    return "revise" if state.get("critic_review", {}).get("overall_status") == "REVISE" else "report"


def build_analysis_graph(llm_client: Any | None = None) -> Any:
    llm_client = llm_client or get_ollama_client()
    agents = {
        "profiler": DataProfilerAgent(llm_client),
        "cleaner": DataCleaningAgent(llm_client),
        "planner": AnalysisPlannerAgent(llm_client),
        "statistical": StatisticalAnalystAgent(llm_client),
        "visualization": VisualizationAgent(llm_client),
        "ml": MLAnalystAgent(llm_client),
        "knowledge": KnowledgeAgent(llm_client),
        "hypothesis": HypothesisGeneratorAgent(llm_client),
        "critic": CriticAgent(llm_client),
        "report": ReportWriterAgent(llm_client),
    }

    graph = StateGraph(AnalysisState)
    for node_name, agent in agents.items():
        graph.add_node(node_name, agent.run)
    graph.add_node("iteration_guard", enforce_iteration_limit)

    graph.add_edge(START, "profiler")
    graph.add_edge("profiler", "cleaner")
    graph.add_edge("cleaner", "planner")
    graph.add_edge("planner", "statistical")
    graph.add_edge("statistical", "visualization")
    graph.add_edge("visualization", "ml")
    graph.add_edge("ml", "knowledge")
    graph.add_edge("knowledge", "hypothesis")
    graph.add_edge("hypothesis", "critic")
    graph.add_edge("critic", "iteration_guard")
    graph.add_conditional_edges(
        "iteration_guard",
        route_critic,
        {"revise": "planner", "report": "report"},
    )
    graph.add_edge("report", END)
    return graph.compile()
