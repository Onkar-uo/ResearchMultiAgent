from __future__ import annotations

from typing import TypedDict, List, Any


class AnalysisState(TypedDict):
    session_id: str
    dataset_path: str
    user_question: str
    data_profile: dict[str, Any]
    cleaning_report: dict[str, Any]
    cleaned_dataset_path: str
    statistical_analysis: dict[str, Any]
    visualizations: List[dict[str, Any]]
    ml_analysis: dict[str, Any]
    hypotheses: List[dict[str, Any]]
    evidence_catalog: dict[str, Any]
    tool_results: List[dict[str, Any]]
    rag_context: str
    rag_sources: List[dict[str, Any]]
    knowledge_queries: List[dict[str, Any]]
    mcp_tool_calls: List[dict[str, Any]]
    mcp_results: List[dict[str, Any]]
    mcp_server_status: dict[str, Any]
    critic_review: dict[str, Any]
    report_sections: dict[str, Any]
    final_report: str
    iteration: int
    max_iterations: int
    errors: List[dict[str, Any]]
    execution_trace: List[dict[str, Any]]
    profile_interpretation: dict[str, Any]
    cleaning_interpretation: dict[str, Any]
    statistical_interpretation: dict[str, Any]
    ml_interpretation: dict[str, Any]
    summary: str
