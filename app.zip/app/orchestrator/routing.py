from __future__ import annotations

from typing import Any


def route_critic(state: dict[str, Any]) -> str:
    critic_review = state.get("critic_review") or {}
    status = str(critic_review.get("overall_status", "PASS")).upper()
    if status in {"REVISE", "INSUFFICIENT_EVIDENCE"}:
        return "revise"
    return "pass"


def route_after_statistics(state: dict[str, Any]) -> str:
    if state.get("ml_analysis"):
        return "ml"
    return "visualization"
