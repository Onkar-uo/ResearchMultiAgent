from __future__ import annotations

from typing import Any

from fastmcp import FastMCP

from app.rag.service import _default_service

mcp = FastMCP("AI Knowledge Retrieval")


@mcp.tool()
def search_knowledge(query: str, top_k: int = 5, category: str | None = None) -> dict[str, Any]:
    """Search the local embedded knowledge base and include source and similarity for every result."""
    results = _default_service.retrieve_knowledge(query, top_k, category)
    return {"results": results}


@mcp.tool()
def get_document(source: str) -> dict[str, Any]:
    """Read only indexed chunks for one known knowledge source; arbitrary paths are not accepted."""
    chunks = _default_service.get_document(source)
    if not chunks:
        raise ValueError(f"Knowledge source '{source}' is not indexed.")
    return {"source": source, "chunks": chunks}


@mcp.tool()
def list_knowledge_sources() -> dict[str, Any]:
    """List indexed local knowledge sources and chunk counts."""
    return {"sources": _default_service.list_sources()}


@mcp.resource("knowledge://statistics/correlation")
def correlation_resource() -> str:
    """Read-only reference on correlation and causation."""
    return _read_fixed_document("statistics/correlation.md")


@mcp.resource("knowledge://statistics/regression")
def regression_resource() -> str:
    """Read-only reference on regression interpretation."""
    return _read_fixed_document("statistics/regression.md")


@mcp.resource("knowledge://machine_learning/feature_importance")
def feature_importance_resource() -> str:
    """Read-only reference on predictive feature importance."""
    return _read_fixed_document("machine_learning/feature_importance.md")


@mcp.resource("knowledge://business/sales_analysis")
def sales_analysis_resource() -> str:
    """Read-only reference on sales decline analysis."""
    return _read_fixed_document("business/sales_analysis.md")


def _read_fixed_document(source: str) -> str:
    chunks = _default_service.get_document(source)
    if not chunks:
        raise ValueError(f"Knowledge source '{source}' is not indexed; ingest the knowledge base first.")
    return "\n\n".join(chunk["content"] for chunk in chunks)


if __name__ == "__main__":
    mcp.run(transport="stdio")
