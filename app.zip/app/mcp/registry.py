from __future__ import annotations

import asyncio
import threading
from typing import Any

from langchain.mcp import MCPAdapter

from app.config import MCP_ENABLED
from app.mcp.catalog import TOOL_CATALOG
from app.mcp.data_science_server import mcp as data_science_server
from app.mcp.knowledge_server import mcp as knowledge_server
from app.mcp.ml_server import mcp as ml_server
from app.mcp.visualization_server import mcp as visualization_server

SERVERS = {
    "data_science": data_science_server,
    "ml": ml_server,
    "visualization": visualization_server,
    "knowledge": knowledge_server,
}
_TOOL_CACHE: dict[str, list[Any]] = {}


def _run_async(coroutine):
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coroutine)

    result: list[Any] = []
    errors: list[BaseException] = []

    def run_in_thread() -> None:
        try:
            result.append(asyncio.run(coroutine))
        except BaseException as exc:
            errors.append(exc)

    thread = threading.Thread(target=run_in_thread, daemon=True)
    thread.start()
    thread.join()
    if errors:
        raise errors[0]
    return result[0]


class MCPUnavailable(RuntimeError):
    """Raised when a local MCP server cannot be reached or discovered."""


class MCPToolExecutionError(RuntimeError):
    """Raised when an MCP server is reached but its requested tool fails."""


async def _get_langchain_tools(server_name: str) -> list[Any]:
    if server_name not in SERVERS:
        raise MCPUnavailable(f"Unknown MCP server '{server_name}'.")
    if server_name in _TOOL_CACHE:
        return _TOOL_CACHE[server_name]
    try:
        async with MCPAdapter(SERVERS[server_name]) as adapter:
            tools = await adapter.list_tools()
            _TOOL_CACHE[server_name] = tools
            return tools
    except Exception as exc:
        raise MCPUnavailable(f"Could not connect to MCP server '{server_name}': {exc}") from exc


def _tool_schema(tool: Any, server_name: str) -> dict[str, Any]:
    argument_model = getattr(tool, "args_schema", None)
    parameters = (
        argument_model.model_json_schema()
        if hasattr(argument_model, "model_json_schema")
        else {"type": "object", "properties": {}, "additionalProperties": False}
    )
    return {
        "type": "function",
        "function": {
            "name": str(tool.name),
            "description": str(tool.description or f"MCP tool from {server_name}."),
            "parameters": parameters,
        },
    }


async def _discover_registry() -> list[dict[str, Any]]:
    entries = []
    for server_name in SERVERS:
        try:
            tools = await _get_langchain_tools(server_name)
            for tool in tools:
                entries.append(
                    {
                        "server": server_name,
                        "tool": str(tool.name),
                        "description": str(tool.description or ""),
                        "input_schema": _tool_schema(tool, server_name)["function"]["parameters"],
                        "status": "available",
                        "protocol": "MCP via LangChain MCPAdapter (embedded FastMCP server)",
                    }
                )
        except MCPUnavailable as exc:
            entries.append(
                {
                    "server": server_name,
                    "tool": None,
                    "description": "Local MCP server could not be reached.",
                    "input_schema": {},
                    "status": "unavailable",
                    "error": str(exc),
                }
            )
    return entries


def list_mcp_registry(live_check: bool = False) -> list[dict[str, Any]]:
    if not MCP_ENABLED:
        return [
            {
                "server": name,
                "tool": None,
                "description": "MCP is disabled; local Python tools remain available.",
                "input_schema": {},
                "status": "disabled",
            }
            for name in SERVERS
        ]
    if live_check:
        return _run_async(_discover_registry())
    return [
        {
            **tool,
            "status": "configured",
            "protocol": "LangChain MCPAdapter with an embedded local FastMCP server.",
        }
        for tool in TOOL_CATALOG
    ]


async def _list_schemas(server_name: str) -> list[dict[str, Any]]:
    tools = await _get_langchain_tools(server_name)
    return [_tool_schema(tool, server_name) for tool in tools]


def list_langchain_tool_schemas(server_name: str) -> list[dict[str, Any]]:
    return _run_async(_list_schemas(server_name))
