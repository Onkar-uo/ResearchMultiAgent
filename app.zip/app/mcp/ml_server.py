from __future__ import annotations

from typing import Literal

import numpy as np
import pandas as pd
from fastmcp import FastMCP
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.metrics import accuracy_score, f1_score, mean_squared_error, r2_score
from sklearn.model_selection import cross_val_score, train_test_split
from sklearn.preprocessing import LabelEncoder

from app.mcp.common.data_tools import read_authorized_csv

mcp = FastMCP("AI Machine Learning")


def _numeric_features(df: pd.DataFrame, target: str, features: list[str]) -> pd.DataFrame:
    if not features:
        raise ValueError("At least one predictor feature is required.")
    missing = [feature for feature in features if feature not in df.columns]
    if missing:
        raise ValueError(f"Unknown feature columns: {missing}")
    non_numeric = [feature for feature in features if not pd.api.types.is_numeric_dtype(df[feature])]
    if non_numeric:
        raise ValueError(f"Only numeric features are supported; non-numeric: {non_numeric}")
    if target in features:
        raise ValueError("Target column cannot also be a predictor feature.")
    return df[features].apply(lambda column: column.fillna(column.median()))


@mcp.tool()
def train_regression_model(dataset_path: str, target: str, features: list[str]) -> dict:
    """Fit and evaluate a bounded RandomForest regression model on a holdout split."""
    df = read_authorized_csv(dataset_path)
    if target not in df or not pd.api.types.is_numeric_dtype(df[target]):
        raise ValueError("Regression target must exist and be numeric.")
    frame = df[[target, *features]].dropna(subset=[target])
    if len(frame) < 10:
        raise ValueError("At least 10 labeled rows are required.")
    X = _numeric_features(frame, target, features)
    y = frame[target]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=1)
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    return {
        "model": "RandomForestRegressor",
        "target": target,
        "r2": float(r2_score(y_test, predictions)),
        "rmse": float(np.sqrt(mean_squared_error(y_test, predictions))),
        "feature_importance": {
            name: float(score) for name, score in zip(features, model.feature_importances_)
        },
        "train_rows": int(len(X_train)),
        "test_rows": int(len(X_test)),
        "causal_warning": "Model feature importance is predictive, not causal evidence.",
    }


@mcp.tool()
def train_classification_model(dataset_path: str, target: str, features: list[str]) -> dict:
    """Fit a bounded RandomForest classifier on numeric predictors and evaluate a holdout split."""
    df = read_authorized_csv(dataset_path)
    if target not in df:
        raise ValueError(f"Target column '{target}' was not found.")
    frame = df[[target, *features]].dropna(subset=[target])
    labels = LabelEncoder().fit_transform(frame[target].astype(str))
    if len(frame) < 10 or len(np.unique(labels)) < 2:
        raise ValueError("Classification requires at least 10 labeled rows and two classes.")
    counts = np.bincount(labels)
    stratify = labels if counts.min() >= 2 else None
    X = _numeric_features(frame, target, features)
    X_train, X_test, y_train, y_test = train_test_split(
        X, labels, test_size=0.2, random_state=42, stratify=stratify
    )
    model = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=1)
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    return {
        "model": "RandomForestClassifier",
        "target": target,
        "accuracy": float(accuracy_score(y_test, predictions)),
        "f1_weighted": float(f1_score(y_test, predictions, average="weighted", zero_division=0)),
        "feature_importance": {
            name: float(score) for name, score in zip(features, model.feature_importances_)
        },
        "train_rows": int(len(X_train)),
        "test_rows": int(len(X_test)),
    }


@mcp.tool()
def evaluate_model(
    actual: list[float],
    predicted: list[float],
    task_type: Literal["regression", "classification"] = "regression",
) -> dict:
    """Calculate regression or classification evaluation metrics from paired values."""
    if not actual or len(actual) != len(predicted):
        raise ValueError("Actual and predicted values must be non-empty and have equal lengths.")
    if task_type == "regression":
        return {
            "task_type": task_type,
            "r2": float(r2_score(actual, predicted)),
            "rmse": float(np.sqrt(mean_squared_error(actual, predicted))),
            "sample_size": len(actual),
        }
    return {
        "task_type": task_type,
        "accuracy": float(accuracy_score(actual, predicted)),
        "f1_weighted": float(f1_score(actual, predicted, average="weighted", zero_division=0)),
        "sample_size": len(actual),
    }


@mcp.tool()
def get_feature_importance(
    dataset_path: str,
    target: str,
    features: list[str],
    task_type: Literal["regression", "classification"] = "regression",
) -> dict:
    """Fit a forest and return predictive feature importance, not a causal estimate."""
    result = (
        train_regression_model(dataset_path, target, features)
        if task_type == "regression"
        else train_classification_model(dataset_path, target, features)
    )
    return {
        "model": result["model"],
        "target": target,
        "feature_importance": result["feature_importance"],
        "interpretation": "Predictive importance does not show that a feature caused the outcome.",
    }


@mcp.tool()
def cross_validate_model(
    dataset_path: str,
    target: str,
    features: list[str],
    task_type: Literal["regression", "classification"] = "regression",
    folds: int = 5,
) -> dict:
    """Run bounded K-fold cross-validation on a numeric-feature random forest."""
    if folds < 2 or folds > 10:
        raise ValueError("folds must be between 2 and 10.")
    df = read_authorized_csv(dataset_path)
    if target not in df:
        raise ValueError(f"Target column '{target}' was not found.")
    frame = df[[target, *features]].dropna(subset=[target])
    X = _numeric_features(frame, target, features)
    if task_type == "regression":
        y = frame[target]
        estimator = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=1)
        scoring = "r2"
    else:
        y = LabelEncoder().fit_transform(frame[target].astype(str))
        estimator = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=1)
        scoring = "accuracy"
    if len(y) < folds:
        raise ValueError("Number of rows must be at least the number of folds.")
    scores = cross_val_score(estimator, X, y, cv=folds, scoring=scoring, n_jobs=1)
    return {
        "task_type": task_type,
        "scoring": scoring,
        "folds": folds,
        "scores": [float(value) for value in scores],
        "mean_score": float(scores.mean()),
        "std_score": float(scores.std()),
    }


if __name__ == "__main__":
    mcp.run(transport="stdio")
