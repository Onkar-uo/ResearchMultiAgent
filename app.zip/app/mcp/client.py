from __future__ import annotations

import json
import time
from typing import Any, Callable

from app.config import MCP_ENABLED
from app.mcp.registry import MCPToolExecutionError, MCPUnavailable, SERVERS, _get_langchain_tools, _run_async


async def _call_mcp(server_name: str, tool_name: str, arguments: dict[str, Any]) -> Any:
    tools = await _get_langchain_tools(server_name)
    tool = next((candidate for candidate in tools if candidate.name == tool_name), None)
    if tool is None:
        raise MCPUnavailable(f"Tool '{tool_name}' was not advertised by MCP server '{server_name}'.")
    try:
        return await tool.ainvoke(arguments)
    except Exception as exc:
        raise MCPToolExecutionError(f"MCP tool '{server_name}.{tool_name}' failed: {exc}") from exc


def _normalize_result(value: Any) -> Any:
    if isinstance(value, str):
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            return value
    if isinstance(value, list):
        content = []
        for item in value:
            text = getattr(item, "text", None)
            if text is None and isinstance(item, dict):
                text = item.get("text")
            if isinstance(text, str):
                try:
                    content.append(json.loads(text))
                except json.JSONDecodeError:
                    content.append(text)
            else:
                content.append(item)
        if len(content) == 1:
            return content[0]
        return content
    if hasattr(value, "model_dump"):
        return value.model_dump()
    return value


class MCPClient:
    """LangChain-backed MCP discovery and call gateway with explicit local fallback."""

    def call_tool(
        self,
        server_name: str,
        tool_name: str,
        arguments: dict[str, Any],
        fallback: Callable[[], Any] | None = None,
    ) -> tuple[Any, dict[str, Any]]:
        started = time.perf_counter()
        error: str | None = None
        if MCP_ENABLED:
            try:
                value = _run_async(_call_mcp(server_name, tool_name, arguments))
                result = _normalize_result(value)
                return result, {
                    "server": server_name,
                    "tool": tool_name,
                    "status": "success",
                    "duration": round(time.perf_counter() - started, 4),
                    "arguments": arguments,
                    "result_summary": str(result)[:500],
                    "error": None,
                }
            except MCPUnavailable as exc:
                error = str(exc)
        else:
            error = "MCP is disabled by configuration."

        if fallback is None:
            raise MCPUnavailable(error or "MCP unavailable and no local fallback is configured.")
        try:
            result = fallback()
        except Exception as exc:
            raise MCPToolExecutionError(
                f"{error or 'MCP unavailable'}; local fallback for '{tool_name}' failed: {exc}"
            ) from exc
        return result, {
            "server": server_name,
            "tool": tool_name,
            "status": "fallback",
            "duration": round(time.perf_counter() - started, 4),
            "arguments": arguments,
            "result_summary": str(result)[:500],
            "error": error,
            "fallback": "local Python tool",
        }
