from __future__ import annotations

from typing import Literal

from fastmcp import FastMCP

from app.mcp.common.data_tools import (
    analyze_time_series as _analyze_time_series,
    calculate_correlation as _calculate_correlation,
    column_statistics,
    compare_groups,
    detect_outliers as _detect_outliers,
    profile_dataset as _profile_dataset,
)

mcp = FastMCP("AI Data Science")


@mcp.tool()
def profile_dataset(dataset_path: str) -> dict:
    """Profile an authorized uploaded CSV: row/column counts, types, missingness and duplicates."""
    return _profile_dataset(dataset_path)


@mcp.tool()
def get_column_statistics(dataset_path: str, column: str) -> dict:
    """Calculate deterministic descriptive statistics for a column in an authorized CSV."""
    return column_statistics(dataset_path, column)


@mcp.tool()
def calculate_correlation(
    dataset_path: str,
    column_a: str,
    column_b: str,
    method: Literal["pearson", "spearman"] = "pearson",
) -> dict:
    """Calculate numeric correlation and p-value using Python; correlation is not causation."""
    return _calculate_correlation(dataset_path, column_a, column_b, method)


@mcp.tool()
def group_analysis(dataset_path: str, group_column: str, value_column: str) -> dict:
    """Compare deterministic descriptive metrics across categorical groups."""
    return compare_groups(dataset_path, group_column, value_column)


@mcp.tool()
def detect_outliers(dataset_path: str, column: str) -> dict:
    """Flag numeric IQR outliers without removing or changing rows."""
    return _detect_outliers(dataset_path, column)


@mcp.tool()
def analyze_time_series(dataset_path: str, date_column: str, value_column: str) -> dict:
    """Aggregate a numeric value monthly and calculate first-to-last change."""
    return _analyze_time_series(dataset_path, date_column, value_column)


if __name__ == "__main__":
    mcp.run(transport="stdio")
