from __future__ import annotations

from typing import Any

def _schema(
    properties: dict[str, dict[str, Any]],
    required: list[str],
) -> dict[str, Any]:
    return {
        "type": "object",
        "properties": properties,
        "required": required,
        "additionalProperties": False,
    }


def _string(description: str) -> dict[str, str]:
    return {"type": "string", "description": description}


def _number(description: str) -> dict[str, str]:
    return {"type": "number", "description": description}


def _string_list(description: str) -> dict[str, Any]:
    return {"type": "array", "items": {"type": "string"}, "description": description}


def _make_tool(
    server: str,
    name: str,
    description: str,
    properties: dict[str, dict[str, Any]],
    required: list[str],
) -> dict[str, Any]:
    return {
        "server": server,
        "tool": name,
        "description": description,
        "input_schema": _schema(properties, required),
    }


_PATH = _string("Path to a CSV inside the application's upload or processed-data directory.")
_SESSION = _string("Safe artifact session identifier.")

TOOL_CATALOG = [
    _make_tool("data_science", "profile_dataset", "Profile shape, types, missingness and duplicates.", {"dataset_path": _PATH}, ["dataset_path"]),
    _make_tool("data_science", "get_column_statistics", "Calculate deterministic column summary statistics.", {"dataset_path": _PATH, "column": _string("Column name.")}, ["dataset_path", "column"]),
    _make_tool("data_science", "calculate_correlation", "Calculate Pearson or Spearman correlation and p-value.", {"dataset_path": _PATH, "column_a": _string("First numeric column."), "column_b": _string("Second numeric column."), "method": {"type": "string", "enum": ["pearson", "spearman"]}}, ["dataset_path", "column_a", "column_b"]),
    _make_tool("data_science", "group_analysis", "Compare descriptive metrics across groups.", {"dataset_path": _PATH, "group_column": _string("Categorical grouping column."), "value_column": _string("Numeric measure.")}, ["dataset_path", "group_column", "value_column"]),
    _make_tool("data_science", "detect_outliers", "Flag IQR outliers without removing rows.", {"dataset_path": _PATH, "column": _string("Numeric column.")}, ["dataset_path", "column"]),
    _make_tool("data_science", "analyze_time_series", "Aggregate a value monthly and measure end-to-end change.", {"dataset_path": _PATH, "date_column": _string("Datetime column."), "value_column": _string("Numeric measure.")}, ["dataset_path", "date_column", "value_column"]),
    _make_tool("ml", "train_regression_model", "Train and holdout-evaluate a RandomForest regressor.", {"dataset_path": _PATH, "target": _string("Numeric outcome column."), "features": _string_list("Numeric predictor columns.")}, ["dataset_path", "target", "features"]),
    _make_tool("ml", "train_classification_model", "Train and holdout-evaluate a RandomForest classifier.", {"dataset_path": _PATH, "target": _string("Class label column."), "features": _string_list("Numeric predictor columns.")}, ["dataset_path", "target", "features"]),
    _make_tool("ml", "evaluate_model", "Calculate regression or classification metrics.", {"actual": {"type": "array", "items": _number("Observed value.")}, "predicted": {"type": "array", "items": _number("Predicted value.")}, "task_type": {"type": "string", "enum": ["regression", "classification"]}}, ["actual", "predicted"]),
    _make_tool("ml", "get_feature_importance", "Return model-specific predictive feature importances.", {"dataset_path": _PATH, "target": _string("Outcome column."), "features": _string_list("Numeric predictors."), "task_type": {"type": "string", "enum": ["regression", "classification"]}}, ["dataset_path", "target", "features"]),
    _make_tool("ml", "cross_validate_model", "Cross-validate a random forest with leakage-aware numeric features.", {"dataset_path": _PATH, "target": _string("Outcome column."), "features": _string_list("Numeric predictors."), "task_type": {"type": "string", "enum": ["regression", "classification"]}, "folds": {"type": "integer", "minimum": 2, "maximum": 10}}, ["dataset_path", "target", "features"]),
    _make_tool("visualization", "generate_time_series_plot", "Save a monthly time-series plot.", {"dataset_path": _PATH, "date_column": _string("Datetime column."), "value_column": _string("Numeric measure."), "session_id": _SESSION}, ["dataset_path", "date_column", "value_column", "session_id"]),
    _make_tool("visualization", "generate_correlation_heatmap", "Save a heatmap of numeric correlations.", {"dataset_path": _PATH, "session_id": _SESSION}, ["dataset_path", "session_id"]),
    _make_tool("visualization", "generate_scatter_plot", "Save a scatter plot for two numeric columns.", {"dataset_path": _PATH, "column_x": _string("Horizontal numeric column."), "column_y": _string("Vertical numeric column."), "session_id": _SESSION}, ["dataset_path", "column_x", "column_y", "session_id"]),
    _make_tool("visualization", "generate_distribution_plot", "Save a numeric column histogram.", {"dataset_path": _PATH, "column": _string("Numeric column."), "session_id": _SESSION}, ["dataset_path", "column", "session_id"]),
    _make_tool("visualization", "generate_feature_importance_plot", "Save a bar chart of precomputed feature importance.", {"features": _string_list("Feature names."), "importances": {"type": "array", "items": _number("Importance value.")}, "session_id": _SESSION}, ["features", "importances", "session_id"]),
    _make_tool("visualization", "generate_group_comparison_plot", "Save a group-mean comparison chart.", {"dataset_path": _PATH, "group_column": _string("Categorical group."), "value_column": _string("Numeric value."), "session_id": _SESSION}, ["dataset_path", "group_column", "value_column", "session_id"]),
    _make_tool("knowledge", "search_knowledge", "Retrieve relevant local knowledge chunks with source citations.", {"query": _string("Retrieval query."), "top_k": {"type": "integer", "minimum": 1, "maximum": 20}, "category": _string("Optional knowledge category.")}, ["query"]),
    _make_tool("knowledge", "get_document", "Read chunks from one indexed knowledge source.", {"source": _string("Indexed source identifier; not a filesystem path.")}, ["source"]),
    _make_tool("knowledge", "list_knowledge_sources", "List indexed knowledge sources and chunk counts.", {}, []),
]


def tool_schema_for(server: str) -> list[dict[str, Any]]:
    return [
        {
            "type": "function",
            "function": {
                "name": tool["tool"],
                "description": tool["description"],
                "parameters": tool["input_schema"],
            },
        }
        for tool in TOOL_CATALOG
        if tool["server"] == server
    ]
