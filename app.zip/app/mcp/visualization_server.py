from __future__ import annotations

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from fastmcp import FastMCP

from app.mcp.common.config import resolve_dataset_path, resolve_plot_path

mcp = FastMCP("AI Visualization")


def _read(dataset_path: str) -> pd.DataFrame:
    return pd.read_csv(resolve_dataset_path(dataset_path))


def _save_plot(session_id: str, filename: str, title: str) -> dict[str, str]:
    path = resolve_plot_path(session_id, filename)
    plt.title(title)
    plt.tight_layout()
    plt.savefig(path)
    plt.close()
    return {"path": str(path), "title": title}


@mcp.tool()
def generate_time_series_plot(
    dataset_path: str,
    date_column: str,
    value_column: str,
    session_id: str,
) -> dict:
    """Save a time-series chart for an authorized CSV and return its artifact path."""
    df = _read(dataset_path)
    if date_column not in df or value_column not in df:
        raise ValueError("Date or value column was not found.")
    if not pd.api.types.is_numeric_dtype(df[value_column]):
        raise ValueError("Value column must be numeric.")
    frame = pd.DataFrame(
        {
            "date": pd.to_datetime(df[date_column], format="mixed", errors="coerce"),
            "value": df[value_column],
        }
    ).dropna()
    if frame.empty:
        raise ValueError("No valid time-series observations were found.")
    frame.set_index("date")["value"].resample("MS").mean().plot(figsize=(8, 4))
    return _save_plot(session_id, "time_series.png", f"{value_column} over time")


@mcp.tool()
def generate_correlation_heatmap(dataset_path: str, session_id: str) -> dict:
    """Save a correlation heatmap for numeric columns in an authorized CSV."""
    numeric = _read(dataset_path).select_dtypes(include="number")
    if numeric.empty:
        raise ValueError("No numeric columns are available.")
    plt.figure(figsize=(8, 6))
    sns.heatmap(numeric.corr(), annot=False, cmap="coolwarm")
    return _save_plot(session_id, "correlation_heatmap.png", "Correlation heatmap")


@mcp.tool()
def generate_scatter_plot(
    dataset_path: str,
    column_x: str,
    column_y: str,
    session_id: str,
) -> dict:
    """Save a scatter plot of two numeric columns."""
    df = _read(dataset_path)
    for column in (column_x, column_y):
        if column not in df or not pd.api.types.is_numeric_dtype(df[column]):
            raise ValueError(f"Column '{column}' must exist and be numeric.")
    df.plot.scatter(x=column_x, y=column_y, figsize=(7, 4))
    return _save_plot(session_id, "scatter.png", f"{column_y} vs {column_x}")


@mcp.tool()
def generate_distribution_plot(dataset_path: str, column: str, session_id: str) -> dict:
    """Save a distribution histogram for a numeric column."""
    df = _read(dataset_path)
    if column not in df or not pd.api.types.is_numeric_dtype(df[column]):
        raise ValueError(f"Column '{column}' must exist and be numeric.")
    df[column].dropna().plot.hist(bins=30, figsize=(7, 4))
    return _save_plot(session_id, "distribution.png", f"Distribution of {column}")


@mcp.tool()
def generate_feature_importance_plot(
    features: list[str],
    importances: list[float],
    session_id: str,
) -> dict:
    """Save a feature-importance bar chart from already computed model results."""
    if not features or len(features) != len(importances):
        raise ValueError("Feature names and importances must be non-empty and have matching lengths.")
    if any(value < 0 for value in importances):
        raise ValueError("Feature importance values must be non-negative.")
    pd.Series(importances, index=features).sort_values().plot.barh(figsize=(7, 4))
    return _save_plot(session_id, "feature_importance.png", "Predictive feature importance")


@mcp.tool()
def generate_group_comparison_plot(
    dataset_path: str,
    group_column: str,
    value_column: str,
    session_id: str,
) -> dict:
    """Save a chart of group means from an authorized CSV."""
    df = _read(dataset_path)
    if group_column not in df or value_column not in df:
        raise ValueError("Group or value column was not found.")
    if not pd.api.types.is_numeric_dtype(df[value_column]):
        raise ValueError("Value column must be numeric.")
    df.groupby(group_column, dropna=False)[value_column].mean().sort_values().plot.barh(figsize=(7, 4))
    return _save_plot(session_id, "group_comparison.png", f"{value_column} by {group_column}")


if __name__ == "__main__":
    mcp.run(transport="stdio")
