from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd
from scipy import stats

from app.tools.profiling_tools import profile_dataset as local_profile_dataset
from app.tools.statistics_tools import group_analysis, time_trend_analysis


def run_data_science_fallback(
    tool_name: str,
    arguments: dict[str, Any],
    trusted_dataset_path: str,
) -> dict[str, Any]:
    df = pd.read_csv(trusted_dataset_path)
    if tool_name == "profile_dataset":
        return local_profile_dataset(trusted_dataset_path)

    if tool_name == "get_column_statistics":
        column = arguments["column"]
        if column not in df:
            raise ValueError(f"Column '{column}' was not found.")
        series = df[column]
        if pd.api.types.is_numeric_dtype(series):
            values = series.dropna()
            return {
                "column": column,
                "count": int(values.count()),
                "missing": int(series.isna().sum()),
                "mean": float(values.mean()),
                "median": float(values.median()),
                "std": float(values.std()),
                "min": float(values.min()),
                "max": float(values.max()),
            }
        return {
            "column": column,
            "count": int(series.notna().sum()),
            "missing": int(series.isna().sum()),
            "distinct": int(series.nunique(dropna=True)),
        }

    if tool_name == "calculate_correlation":
        column_a, column_b = arguments["column_a"], arguments["column_b"]
        for column in (column_a, column_b):
            if column not in df or not pd.api.types.is_numeric_dtype(df[column]):
                raise ValueError(f"Column '{column}' must exist and be numeric.")
        frame = df[[column_a, column_b]].dropna()
        if len(frame) < 3:
            raise ValueError("At least three complete pairs are required.")
        result = (
            stats.pearsonr(frame[column_a], frame[column_b])
            if arguments.get("method", "pearson") == "pearson"
            else stats.spearmanr(frame[column_a], frame[column_b])
        )
        return {
            "column_a": column_a,
            "column_b": column_b,
            "correlation": float(result.statistic),
            "p_value": float(result.pvalue),
            "method": arguments.get("method", "pearson"),
            "sample_size": int(len(frame)),
            "interpretation_note": "Association only; this statistic does not establish causation.",
        }

    if tool_name == "group_analysis":
        group_column, value_column = arguments["group_column"], arguments["value_column"]
        return {
            "group_column": group_column,
            "value_column": value_column,
            "groups": group_analysis(df, group_column, value_column),
        }

    if tool_name == "detect_outliers":
        column = arguments["column"]
        if column not in df or not pd.api.types.is_numeric_dtype(df[column]):
            raise ValueError(f"Column '{column}' must exist and be numeric.")
        values = df[column].dropna()
        if values.empty:
            raise ValueError(f"Column '{column}' has no values.")
        q1, q3 = values.quantile([0.25, 0.75])
        iqr = q3 - q1
        mask = (values < q1 - 1.5 * iqr) | (values > q3 + 1.5 * iqr)
        return {
            "column": column,
            "outlier_count": int(mask.sum()),
            "outlier_fraction": float(mask.mean()),
            "outliers_removed": False,
        }

    if tool_name == "analyze_time_series":
        return {
            "monthly": time_trend_analysis(df, arguments["date_column"], arguments["value_column"]),
        }

    raise ValueError(f"No local fallback is registered for '{tool_name}'.")


def run_knowledge_fallback(
    query: str,
    top_k: int = 5,
    category: str | None = None,
) -> dict[str, Any]:
    from app.rag.service import _default_service

    return {"results": _default_service.retrieve_knowledge(query, top_k, category)}
