from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class MCPToolResult(BaseModel):
    model_config = ConfigDict(extra="forbid")
    status: Literal["success", "error"]
    server: str
    tool: str
    result: dict
    error: str | None = None


class MCPToolCallRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")
    server: str
    tool: str
    status: Literal["success", "fallback", "error"]
    duration: float = Field(ge=0)
    arguments: dict
    result_summary: str = ""
    error: str | None = None
