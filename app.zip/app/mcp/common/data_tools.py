from __future__ import annotations

from typing import Any, Literal

import pandas as pd
from scipy import stats

from app.mcp.common.config import resolve_dataset_path


def read_authorized_csv(dataset_path: str) -> pd.DataFrame:
    return pd.read_csv(resolve_dataset_path(dataset_path))


def column_statistics(dataset_path: str, column: str) -> dict[str, Any]:
    df = read_authorized_csv(dataset_path)
    if column not in df:
        raise ValueError(f"Column '{column}' was not found.")
    series = df[column]
    if pd.api.types.is_numeric_dtype(series):
        values = series.dropna()
        if values.empty:
            raise ValueError(f"Column '{column}' has no numeric observations.")
        return {
            "column": column,
            "count": int(values.count()),
            "missing": int(series.isna().sum()),
            "mean": float(values.mean()),
            "median": float(values.median()),
            "std": float(values.std()),
            "min": float(values.min()),
            "max": float(values.max()),
            "quantiles": {str(key): float(value) for key, value in values.quantile([0.25, 0.5, 0.75]).items()},
        }
    return {
        "column": column,
        "count": int(series.notna().sum()),
        "missing": int(series.isna().sum()),
        "distinct": int(series.nunique(dropna=True)),
        "top_values": {str(key): int(value) for key, value in series.value_counts(dropna=True).head(10).items()},
    }


def calculate_correlation(
    dataset_path: str,
    column_a: str,
    column_b: str,
    method: Literal["pearson", "spearman"] = "pearson",
) -> dict[str, Any]:
    df = read_authorized_csv(dataset_path)
    for column in (column_a, column_b):
        if column not in df:
            raise ValueError(f"Column '{column}' was not found.")
        if not pd.api.types.is_numeric_dtype(df[column]):
            raise ValueError(f"Column '{column}' must be numeric.")
    paired = df[[column_a, column_b]].dropna()
    if len(paired) < 3:
        raise ValueError("At least three complete paired observations are required.")
    if method == "pearson":
        result = stats.pearsonr(paired[column_a], paired[column_b])
    else:
        result = stats.spearmanr(paired[column_a], paired[column_b])
    return {
        "column_a": column_a,
        "column_b": column_b,
        "correlation": float(result.statistic),
        "p_value": float(result.pvalue),
        "method": method,
        "sample_size": int(len(paired)),
        "interpretation_note": "Association only; this statistic does not establish causation.",
    }


def compare_groups(dataset_path: str, group_column: str, value_column: str) -> dict[str, Any]:
    df = read_authorized_csv(dataset_path)
    if group_column not in df or value_column not in df:
        raise ValueError("Group or value column was not found.")
    if not pd.api.types.is_numeric_dtype(df[value_column]):
        raise ValueError(f"Value column '{value_column}' must be numeric.")
    grouped = df.groupby(group_column, dropna=False)[value_column].agg(["count", "mean", "median", "std"])
    return {
        "group_column": group_column,
        "value_column": value_column,
        "groups": [
            {
                "group": str(index),
                "count": int(row["count"]),
                "mean": float(row["mean"]),
                "median": float(row["median"]),
                "std": float(row["std"]) if pd.notna(row["std"]) else None,
            }
            for index, row in grouped.iterrows()
        ],
    }


def detect_outliers(dataset_path: str, column: str) -> dict[str, Any]:
    df = read_authorized_csv(dataset_path)
    if column not in df or not pd.api.types.is_numeric_dtype(df[column]):
        raise ValueError(f"Column '{column}' must exist and be numeric.")
    values = df[column].dropna()
    if values.empty:
        raise ValueError(f"Column '{column}' has no numeric observations.")
    q1, q3 = values.quantile([0.25, 0.75])
    iqr = q3 - q1
    lower, upper = float(q1 - 1.5 * iqr), float(q3 + 1.5 * iqr)
    mask = (values < lower) | (values > upper)
    return {
        "column": column,
        "method": "IQR 1.5x",
        "lower_bound": lower,
        "upper_bound": upper,
        "outlier_count": int(mask.sum()),
        "outlier_fraction": float(mask.mean()),
        "outliers_removed": False,
    }


def analyze_time_series(dataset_path: str, date_column: str, value_column: str) -> dict[str, Any]:
    df = read_authorized_csv(dataset_path)
    if date_column not in df or value_column not in df:
        raise ValueError("Date or value column was not found.")
    if not pd.api.types.is_numeric_dtype(df[value_column]):
        raise ValueError(f"Value column '{value_column}' must be numeric.")
    dates = pd.to_datetime(df[date_column], format="mixed", errors="coerce")
    frame = pd.DataFrame({"date": dates, "value": df[value_column]}).dropna()
    if frame.empty:
        raise ValueError("No valid date and numeric-value pairs were found.")
    monthly = frame.set_index("date")["value"].resample("MS").agg(["mean", "count"])
    observations = [
        {"period": str(index.date()), "mean": float(row["mean"]), "count": int(row["count"])}
        for index, row in monthly.iterrows()
    ]
    first, last = observations[0]["mean"], observations[-1]["mean"]
    change_pct = ((last - first) / abs(first) * 100) if first else None
    return {
        "date_column": date_column,
        "value_column": value_column,
        "monthly": observations,
        "first_to_last_change_pct": float(change_pct) if change_pct is not None else None,
        "sample_size": int(len(frame)),
    }


def profile_dataset(dataset_path: str) -> dict[str, Any]:
    df = read_authorized_csv(dataset_path)
    numerical = df.select_dtypes(include="number")
    return {
        "rows": int(df.shape[0]),
        "columns": int(df.shape[1]),
        "column_names": [str(column) for column in df.columns],
        "numeric_columns": [str(column) for column in numerical.columns],
        "missing_values": {str(key): int(value) for key, value in df.isna().sum().items() if value},
        "duplicate_rows": int(df.duplicated().sum()),
    }
