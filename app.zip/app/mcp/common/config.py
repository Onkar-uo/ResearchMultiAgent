from __future__ import annotations

from pathlib import Path

from app.config import ARTIFACTS_DIR, MAX_FILE_SIZE_MB, PROCESSED_DIR, UPLOAD_DIR

DATASET_ROOTS = (UPLOAD_DIR.resolve(), PROCESSED_DIR.resolve())
ALLOWED_DATASET_EXTENSIONS = {".csv"}


class MCPInputError(ValueError):
    """Raised when an MCP tool receives an invalid or unauthorized argument."""


def resolve_dataset_path(dataset_path: str) -> Path:
    candidate = Path(dataset_path).expanduser().resolve(strict=True)
    if not candidate.is_file():
        raise MCPInputError("Dataset path must identify a file.")
    if candidate.suffix.lower() not in ALLOWED_DATASET_EXTENSIONS:
        raise MCPInputError("Only CSV datasets can be accessed through MCP tools.")
    if candidate.stat().st_size > MAX_FILE_SIZE_MB * 1024 * 1024:
        raise MCPInputError(f"Dataset exceeds the {MAX_FILE_SIZE_MB} MB limit.")
    if not any(candidate.is_relative_to(root) for root in DATASET_ROOTS):
        raise MCPInputError("Dataset path is outside the application's upload and processed-data directories.")
    return candidate


def resolve_plot_path(session_id: str, filename: str) -> Path:
    safe_session = "".join(char for char in session_id if char.isalnum() or char in "-_")
    safe_filename = "".join(char for char in filename if char.isalnum() or char in "-_.")
    if not safe_session or not safe_filename or safe_filename in {".", ".."}:
        raise MCPInputError("Invalid artifact path.")
    target_dir = (ARTIFACTS_DIR / safe_session / "plots").resolve()
    if not target_dir.is_relative_to(ARTIFACTS_DIR.resolve()):
        raise MCPInputError("Artifact path is outside the application's artifact directory.")
    target_dir.mkdir(parents=True, exist_ok=True)
    return target_dir / safe_filename
