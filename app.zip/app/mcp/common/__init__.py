"""Shared MCP server validation and schemas."""
