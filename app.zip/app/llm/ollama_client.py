from __future__ import annotations

import json
import re
from typing import Any

import requests
from pydantic import BaseModel, ValidationError

from app.config import OLLAMA_BASE_URL, OLLAMA_MODEL, TEMPERATURE


class OllamaError(RuntimeError):
    """Raised when Ollama cannot return a valid response."""


class OllamaClient:
    def __init__(self, base_url: str | None = None, model: str | None = None, temperature: float = TEMPERATURE) -> None:
        self.base_url = (base_url or OLLAMA_BASE_URL).rstrip("/")
        self.model = model or OLLAMA_MODEL
        self.temperature = temperature

    def generate(self, prompt: str, system_prompt: str | None = None) -> str:
        try:
            payload = {
                "model": self.model,
                "prompt": prompt,
                "system": system_prompt or "You are a careful analytical assistant.",
                "stream": False,
                "options": {"temperature": self.temperature},
            }
            response = requests.post(f"{self.base_url}/api/generate", json=payload, timeout=30)
            response.raise_for_status()
            data = response.json()
            text = str(data.get("response", "")).strip()
            if not text:
                raise OllamaError("Ollama returned an empty response.")
            return text
        except requests.RequestException as exc:
            raise OllamaError(f"Could not reach Ollama at {self.base_url}: {exc}") from exc
        except (ValueError, KeyError) as exc:
            raise OllamaError(f"Ollama returned an invalid response: {exc}") from exc

    def generate_json(self, prompt: str, system_prompt: str | None = None) -> dict[str, Any]:
        text = self.generate(prompt, system_prompt)
        try:
            return self._parse_json(text)
        except ValueError as exc:
            raise OllamaError(f"Ollama did not return valid JSON: {exc}") from exc

    def generate_structured(
        self,
        prompt: str,
        output_model: type[BaseModel],
        system_prompt: str | None = None,
    ) -> BaseModel:
        schema = output_model.model_json_schema()
        request_prompt = (
            f"{prompt}\n\nReturn only one JSON object that validates against this JSON schema:\n"
            f"{json.dumps(schema, ensure_ascii=False)}"
        )
        correction: str | None = None
        for attempt in range(2):
            current_prompt = request_prompt if correction is None else f"{request_prompt}\n\nCorrection: {correction}"
            text = self.generate(current_prompt, system_prompt)
            try:
                return output_model.model_validate(self._parse_json(text))
            except (ValueError, ValidationError, json.JSONDecodeError) as exc:
                if attempt == 1:
                    raise OllamaError(f"Ollama output failed {output_model.__name__} validation: {exc}") from exc
                correction = f"Your previous JSON was invalid ({exc}). Return corrected JSON only."
        raise OllamaError("Ollama response validation did not complete.")

    def call_tools(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        payload = {
            "model": self.model,
            "messages": messages,
            "tools": tools,
            "stream": False,
            "options": {"temperature": self.temperature},
        }
        try:
            response = requests.post(f"{self.base_url}/api/chat", json=payload, timeout=45)
            response.raise_for_status()
            message = response.json().get("message", {})
            calls = message.get("tool_calls", [])
            if not isinstance(calls, list):
                raise OllamaError("Ollama returned tool calls in an invalid format.")
            return calls
        except requests.RequestException as exc:
            raise OllamaError(f"Ollama tool calling failed at {self.base_url}: {exc}") from exc
        except (ValueError, AttributeError) as exc:
            raise OllamaError(f"Ollama returned an invalid tool-call response: {exc}") from exc

    @staticmethod
    def _parse_json(text: str) -> dict[str, Any]:
        candidate = text.strip()
        candidate = re.sub(r"^```(?:json)?\s*|\s*```$", "", candidate, flags=re.IGNORECASE)
        try:
            result = json.loads(candidate)
        except json.JSONDecodeError:
            start, end = candidate.find("{"), candidate.rfind("}")
            if start < 0 or end < start:
                raise
            result = json.loads(candidate[start : end + 1])
        if not isinstance(result, dict):
            raise ValueError("Expected a JSON object.")
        return result


def get_ollama_client() -> OllamaClient:
    return OllamaClient()
