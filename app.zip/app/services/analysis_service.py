from __future__ import annotations

import uuid
from datetime import datetime, timezone
from pathlib import Path

from app.config import MAX_ANALYSIS_ITERATIONS
from app.mcp.common.config import resolve_dataset_path
from app.models.database import DatabaseManager
from app.orchestrator.graph import build_analysis_graph


class AnalysisService:
    def __init__(self) -> None:
        self.db = DatabaseManager()

    def execute(self, dataset_path: str | Path, user_question: str, session_id: str | None = None) -> dict:
        dataset_path = str(resolve_dataset_path(str(dataset_path)))
        session_id = session_id or uuid.uuid4().hex
        initial_state = {
            "session_id": session_id,
            "dataset_path": dataset_path,
            "user_question": user_question,
            "data_profile": {},
            "cleaning_report": {},
            "cleaned_dataset_path": dataset_path,
            "statistical_analysis": {},
            "visualizations": [],
            "ml_analysis": {},
            "hypotheses": [],
            "evidence_catalog": {},
            "tool_results": [],
            "rag_context": "",
            "rag_sources": [],
            "knowledge_queries": [],
            "mcp_tool_calls": [],
            "mcp_results": [],
            "mcp_server_status": {},
            "critic_review": {},
            "report_sections": {},
            "final_report": "",
            "iteration": 0,
            "max_iterations": MAX_ANALYSIS_ITERATIONS,
            "errors": [],
            "execution_trace": [],
            "profile_interpretation": {},
            "cleaning_interpretation": {},
            "statistical_interpretation": {},
            "ml_interpretation": {},
            "summary": "",
        }
        self.db.save_session(session_id, dataset_path, user_question)
        graph = build_analysis_graph()
        result = graph.invoke(initial_state)
        self.db.write_execution_json(
            session_id,
            {
                "session_id": session_id,
                "iteration": result.get("iteration", 0),
                "critic_review": result.get("critic_review", {}),
                "errors": result.get("errors", []),
                "execution_trace": result.get("execution_trace", []),
            },
        )
        self.db.save_session(session_id, dataset_path, user_question, result.get("final_report", ""), "completed")
        return result


def run_analysis(dataset_path: str | Path, user_question: str, session_id: str | None = None) -> dict:
    return AnalysisService().execute(dataset_path, user_question, session_id)
