from __future__ import annotations

from pathlib import Path
from typing import Any

from app.config import KNOWLEDGE_DIR, RAG_TOP_K
from app.rag.embeddings import OllamaEmbeddingClient
from app.rag.ingestion import ingest_knowledge_base
from app.rag.retriever import retrieve_knowledge as _retrieve_knowledge
from app.rag.vector_store import SQLiteVectorStore


class RAGService:
    def __init__(
        self,
        knowledge_dir: Path = KNOWLEDGE_DIR,
        store: SQLiteVectorStore | None = None,
        embeddings: OllamaEmbeddingClient | None = None,
    ) -> None:
        self.knowledge_dir = knowledge_dir
        self.store = store or SQLiteVectorStore()
        self.embeddings = embeddings or OllamaEmbeddingClient()

    def ingest(self) -> dict[str, Any]:
        return ingest_knowledge_base(self.knowledge_dir, self.store, self.embeddings)

    def retrieve_knowledge(
        self,
        query: str,
        top_k: int = RAG_TOP_K,
        category: str | None = None,
        threshold: float | None = None,
    ) -> list[dict[str, Any]]:
        self.ingest()
        kwargs: dict[str, Any] = {
            "query": query,
            "top_k": top_k,
            "category": category,
            "store": self.store,
            "embeddings": self.embeddings,
        }
        if threshold is not None:
            kwargs["threshold"] = threshold
        return _retrieve_knowledge(**kwargs)

    def list_sources(self) -> list[dict[str, Any]]:
        return self.store.list_sources()

    def get_document(self, source: str) -> list[dict[str, Any]]:
        return self.store.document(source)


_default_service = RAGService()


def retrieve_knowledge(
    query: str,
    top_k: int = RAG_TOP_K,
    category: str | None = None,
) -> list[dict[str, Any]]:
    return _default_service.retrieve_knowledge(query=query, top_k=top_k, category=category)
