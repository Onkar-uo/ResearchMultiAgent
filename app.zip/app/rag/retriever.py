from __future__ import annotations

from typing import Any

from app.config import RAG_SIMILARITY_THRESHOLD, RAG_TOP_K
from app.rag.embeddings import OllamaEmbeddingClient
from app.rag.vector_store import SQLiteVectorStore


def retrieve_knowledge(
    query: str,
    top_k: int = RAG_TOP_K,
    category: str | None = None,
    store: SQLiteVectorStore | None = None,
    embeddings: OllamaEmbeddingClient | None = None,
    threshold: float = RAG_SIMILARITY_THRESHOLD,
) -> list[dict[str, Any]]:
    normalized_query = query.strip()
    if not normalized_query:
        raise ValueError("Knowledge query must not be empty.")
    if top_k < 1 or top_k > 20:
        raise ValueError("top_k must be between 1 and 20.")
    store = store or SQLiteVectorStore()
    embeddings = embeddings or OllamaEmbeddingClient()
    query_vector = embeddings.embed_query(normalized_query)
    return store.search(query_vector, top_k=top_k, category=category, threshold=threshold)
