from __future__ import annotations

from typing import Sequence

import numpy as np
import requests

from app.config import OLLAMA_BASE_URL, OLLAMA_EMBEDDING_MODEL


class EmbeddingError(RuntimeError):
    """Raised when the configured local embedding model cannot embed text."""


class OllamaEmbeddingClient:
    def __init__(
        self,
        base_url: str = OLLAMA_BASE_URL,
        model: str = OLLAMA_EMBEDDING_MODEL,
        timeout: float = 60.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.timeout = timeout

    def embed_documents(self, texts: Sequence[str]) -> list[list[float]]:
        if not texts:
            return []
        embeddings: list[list[float]] = []
        batch_size = 32
        for start in range(0, len(texts), batch_size):
            batch = list(texts[start : start + batch_size])
            try:
                response = requests.post(
                    f"{self.base_url}/api/embed",
                    json={"model": self.model, "input": batch},
                    timeout=self.timeout,
                )
                if response.status_code in {404, 405}:
                    embeddings.extend(self._legacy_embed(batch))
                    continue
                response.raise_for_status()
                values = response.json().get("embeddings")
                if not isinstance(values, list) or len(values) != len(batch):
                    raise EmbeddingError("Ollama returned an unexpected embeddings response.")
                embeddings.extend(self._validate_embedding(value) for value in values)
            except requests.RequestException as exc:
                raise EmbeddingError(
                    f"Could not embed text with local Ollama model '{self.model}': {exc}"
                ) from exc
            except (ValueError, TypeError, KeyError) as exc:
                raise EmbeddingError(f"Invalid embeddings response from Ollama: {exc}") from exc
        return embeddings

    def embed_query(self, text: str) -> list[float]:
        return self.embed_documents([text])[0]

    def _legacy_embed(self, texts: Sequence[str]) -> list[list[float]]:
        results = []
        for text in texts:
            try:
                response = requests.post(
                    f"{self.base_url}/api/embeddings",
                    json={"model": self.model, "prompt": text},
                    timeout=self.timeout,
                )
                response.raise_for_status()
                results.append(self._validate_embedding(response.json()["embedding"]))
            except (requests.RequestException, KeyError, TypeError, ValueError) as exc:
                raise EmbeddingError(
                    f"Could not embed text with local Ollama model '{self.model}': {exc}"
                ) from exc
        return results

    @staticmethod
    def _validate_embedding(value: object) -> list[float]:
        if not isinstance(value, list) or not value:
            raise EmbeddingError("Ollama returned an empty or invalid embedding.")
        array = np.asarray(value, dtype=np.float32)
        if array.ndim != 1 or not np.isfinite(array).all():
            raise EmbeddingError("Ollama returned a non-finite or malformed embedding.")
        norm = float(np.linalg.norm(array))
        if norm == 0:
            raise EmbeddingError("Ollama returned a zero-vector embedding.")
        return (array / norm).astype(np.float32).tolist()
