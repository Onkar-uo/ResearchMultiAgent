from __future__ import annotations

import hashlib
import json
import sqlite3
from pathlib import Path
from typing import Any, Sequence

import numpy as np

from app.config import VECTOR_DB_PATH


class SQLiteVectorStore:
    """Small local cosine-similarity store backed by SQLite."""

    def __init__(self, path: str | Path = VECTOR_DB_PATH) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path)
        connection.row_factory = sqlite3.Row
        return connection

    def _initialize(self) -> None:
        with self._connect() as connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS knowledge_chunks (
                    chunk_id TEXT PRIMARY KEY,
                    content_hash TEXT NOT NULL,
                    source TEXT NOT NULL,
                    category TEXT NOT NULL,
                    document_type TEXT NOT NULL,
                    content TEXT NOT NULL,
                    metadata_json TEXT NOT NULL,
                    embedding_json TEXT NOT NULL,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                )
                """
            )
            connection.execute(
                "CREATE INDEX IF NOT EXISTS idx_knowledge_category ON knowledge_chunks(category)"
            )

    def add_chunks(
        self,
        chunks: Sequence[dict[str, Any]],
        embeddings: Sequence[Sequence[float]],
    ) -> int:
        if len(chunks) != len(embeddings):
            raise ValueError("Chunk and embedding counts must match.")
        rows = []
        for chunk, embedding in zip(chunks, embeddings):
            content = str(chunk["content"])
            digest = hashlib.sha256(content.encode("utf-8")).hexdigest()
            metadata = {
                "source": str(chunk["source"]),
                "category": str(chunk["category"]),
                "document_type": str(chunk["document_type"]),
                "chunk_id": str(chunk["chunk_id"]),
            }
            rows.append(
                (
                    metadata["chunk_id"],
                    digest,
                    metadata["source"],
                    metadata["category"],
                    metadata["document_type"],
                    content,
                    json.dumps(metadata, ensure_ascii=False),
                    json.dumps([float(item) for item in embedding]),
                )
            )
        with self._connect() as connection:
            connection.executemany(
                """
                INSERT INTO knowledge_chunks (
                    chunk_id, content_hash, source, category, document_type,
                    content, metadata_json, embedding_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(chunk_id) DO UPDATE SET
                    content_hash=excluded.content_hash,
                    source=excluded.source,
                    category=excluded.category,
                    document_type=excluded.document_type,
                    content=excluded.content,
                    metadata_json=excluded.metadata_json,
                    embedding_json=excluded.embedding_json,
                    created_at=CURRENT_TIMESTAMP
                """,
                rows,
            )
        return len(rows)

    def has_content(self, chunk_id: str, content_hash: str) -> bool:
        with self._connect() as connection:
            row = connection.execute(
                "SELECT 1 FROM knowledge_chunks WHERE chunk_id=? AND content_hash=?",
                (chunk_id, content_hash),
            ).fetchone()
        return row is not None

    def prune_source(self, source: str, keep_chunk_ids: Sequence[str]) -> None:
        with self._connect() as connection:
            if keep_chunk_ids:
                placeholders = ",".join("?" for _ in keep_chunk_ids)
                connection.execute(
                    f"DELETE FROM knowledge_chunks WHERE source=? AND chunk_id NOT IN ({placeholders})",
                    (source, *keep_chunk_ids),
                )
            else:
                connection.execute("DELETE FROM knowledge_chunks WHERE source=?", (source,))

    def search(
        self,
        query_embedding: Sequence[float],
        top_k: int = 5,
        category: str | None = None,
        threshold: float = -1.0,
    ) -> list[dict[str, Any]]:
        if top_k < 1:
            raise ValueError("top_k must be a positive integer.")
        query = np.asarray(query_embedding, dtype=np.float32)
        if query.ndim != 1 or not query.size or not np.isfinite(query).all():
            raise ValueError("query_embedding must be a finite, non-empty vector.")
        norm = float(np.linalg.norm(query))
        if not norm:
            raise ValueError("query_embedding must not be a zero vector.")
        query /= norm

        with self._connect() as connection:
            if category:
                rows = connection.execute(
                    "SELECT * FROM knowledge_chunks WHERE category=?",
                    (category,),
                ).fetchall()
            else:
                rows = connection.execute("SELECT * FROM knowledge_chunks").fetchall()

        matches: list[dict[str, Any]] = []
        for row in rows:
            vector = np.asarray(json.loads(row["embedding_json"]), dtype=np.float32)
            if vector.shape != query.shape:
                continue
            score = float(np.dot(query, vector))
            if score >= threshold:
                matches.append(
                    {
                        "content": row["content"],
                        "source": row["source"],
                        "score": score,
                        "metadata": json.loads(row["metadata_json"]),
                    }
                )
        matches.sort(key=lambda item: item["score"], reverse=True)
        return matches[:top_k]

    def list_sources(self) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT source, category, document_type, COUNT(*) AS chunk_count
                FROM knowledge_chunks
                GROUP BY source, category, document_type
                ORDER BY category, source
                """
            ).fetchall()
        return [dict(row) for row in rows]

    def document(self, source: str) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT * FROM knowledge_chunks WHERE source=? ORDER BY chunk_id",
                (source,),
            ).fetchall()
        return [
            {
                "content": row["content"],
                "source": row["source"],
                "metadata": json.loads(row["metadata_json"]),
            }
            for row in rows
        ]

    def count(self) -> int:
        with self._connect() as connection:
            row = connection.execute("SELECT COUNT(*) FROM knowledge_chunks").fetchone()
        return int(row[0])
