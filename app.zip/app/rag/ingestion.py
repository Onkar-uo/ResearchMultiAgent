from __future__ import annotations

import hashlib
import logging
from pathlib import Path
from typing import Any

from pypdf import PdfReader

from app.config import KNOWLEDGE_DIR, MAX_FILE_SIZE_MB
from app.rag.chunking import split_text
from app.rag.embeddings import OllamaEmbeddingClient
from app.rag.vector_store import SQLiteVectorStore

logger = logging.getLogger(__name__)
SUPPORTED_EXTENSIONS = {".md", ".txt", ".pdf"}


class IngestionError(RuntimeError):
    """Raised for invalid or unreadable knowledge documents."""


def resolve_knowledge_path(path: str | Path, knowledge_dir: Path = KNOWLEDGE_DIR) -> Path:
    candidate = Path(path).expanduser().resolve(strict=True)
    allowed_root = knowledge_dir.resolve()
    try:
        candidate.relative_to(allowed_root)
    except ValueError as exc:
        raise IngestionError("Knowledge document must be inside the configured knowledge directory.") from exc
    if not candidate.is_file():
        raise IngestionError("Knowledge path must identify a file.")
    if candidate.suffix.lower() not in SUPPORTED_EXTENSIONS:
        raise IngestionError(f"Unsupported knowledge document type: {candidate.suffix}")
    max_bytes = MAX_FILE_SIZE_MB * 1024 * 1024
    if candidate.stat().st_size > max_bytes:
        raise IngestionError(f"Knowledge document exceeds the {MAX_FILE_SIZE_MB} MB limit.")
    return candidate


def load_document(path: str | Path, knowledge_dir: Path = KNOWLEDGE_DIR) -> dict[str, Any]:
    document_path = resolve_knowledge_path(path, knowledge_dir)
    suffix = document_path.suffix.lower()
    try:
        if suffix == ".pdf":
            reader = PdfReader(str(document_path), strict=True)
            if reader.is_encrypted:
                raise IngestionError("Encrypted PDFs are not supported.")
            text = "\n".join(page.extract_text() or "" for page in reader.pages)
        else:
            text = document_path.read_text(encoding="utf-8")
    except (OSError, UnicodeError, ValueError) as exc:
        if isinstance(exc, IngestionError):
            raise
        raise IngestionError(f"Could not read knowledge document '{document_path.name}': {exc}") from exc
    if not text.strip():
        raise IngestionError(f"Knowledge document '{document_path.name}' contains no extractable text.")

    relative = document_path.relative_to(knowledge_dir.resolve()).as_posix()
    category = relative.split("/", maxsplit=1)[0]
    if category == relative:
        category = "general"
    return {
        "text": text,
        "source": relative,
        "category": category,
        "document_type": suffix.lstrip("."),
    }


def ingest_document(
    path: str | Path,
    store: SQLiteVectorStore | None = None,
    embeddings: OllamaEmbeddingClient | None = None,
    knowledge_dir: Path = KNOWLEDGE_DIR,
) -> int:
    store = store or SQLiteVectorStore()
    embeddings = embeddings or OllamaEmbeddingClient()
    document = load_document(path, knowledge_dir)
    chunks = split_text(
        document["text"],
        source=document["source"],
        category=document["category"],
        document_type=document["document_type"],
    )
    pending_chunks = []
    for chunk in chunks:
        digest = hashlib.sha256(chunk["content"].encode("utf-8")).hexdigest()
        if not store.has_content(chunk["chunk_id"], digest):
            pending_chunks.append(chunk)
    if pending_chunks:
        vectors = embeddings.embed_documents([chunk["content"] for chunk in pending_chunks])
        chunks_added = store.add_chunks(pending_chunks, vectors)
    else:
        chunks_added = 0
    store.prune_source(
        document["source"],
        [chunk["chunk_id"] for chunk in chunks],
    )
    return chunks_added


def discover_documents(knowledge_dir: Path = KNOWLEDGE_DIR) -> list[Path]:
    root = knowledge_dir.resolve()
    if not root.exists():
        return []
    documents = []
    for path in root.rglob("*"):
        if path.suffix.lower() not in SUPPORTED_EXTENSIONS:
            continue
        try:
            documents.append(resolve_knowledge_path(path, root))
        except (OSError, IngestionError) as exc:
            logger.warning("Skipping knowledge document %s: %s", path.name, exc)
    return sorted(documents)


def ingest_knowledge_base(
    knowledge_dir: Path = KNOWLEDGE_DIR,
    store: SQLiteVectorStore | None = None,
    embeddings: OllamaEmbeddingClient | None = None,
) -> dict[str, Any]:
    store = store or SQLiteVectorStore()
    embeddings = embeddings or OllamaEmbeddingClient()
    files_seen = 0
    chunks_added = 0
    errors = []
    paths = discover_documents(knowledge_dir)
    current_sources = {
        path.relative_to(knowledge_dir.resolve()).as_posix()
        for path in paths
    }
    for path in paths:
        files_seen += 1
        try:
            chunks_added += ingest_document(path, store, embeddings, knowledge_dir)
        except IngestionError as exc:
            errors.append({"source": path.name, "error": str(exc)})
            logger.warning("Could not ingest %s: %s", path.name, exc)
            source = path.relative_to(knowledge_dir.resolve()).as_posix()
            store.prune_source(source, [])
    for indexed_source in store.list_sources():
        if indexed_source["source"] not in current_sources:
            store.prune_source(indexed_source["source"], [])
    if files_seen and not store.count() and errors:
        raise IngestionError(f"Could not index any knowledge documents: {errors[0]['error']}")
    return {
        "documents_seen": files_seen,
        "chunks_added": chunks_added,
        "indexed_chunks": store.count(),
        "errors": errors,
    }
