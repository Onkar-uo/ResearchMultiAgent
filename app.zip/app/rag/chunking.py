from __future__ import annotations

import re
from typing import Any


def split_text(
    text: str,
    source: str,
    category: str,
    document_type: str,
    chunk_size: int = 1200,
    overlap: int = 160,
) -> list[dict[str, Any]]:
    if chunk_size < 1 or overlap < 0 or overlap >= chunk_size:
        raise ValueError("Require chunk_size > overlap >= 0.")

    normalized = re.sub(r"[ \t]+", " ", text).strip()
    if not normalized:
        return []

    chunks: list[dict[str, Any]] = []
    start = 0
    while start < len(normalized):
        end = min(start + chunk_size, len(normalized))
        if end < len(normalized):
            boundary = normalized.rfind(" ", start, end)
            if boundary > start + chunk_size // 2:
                end = boundary
        content = normalized[start:end].strip()
        if content:
            chunks.append(
                {
                    "content": content,
                    "source": source,
                    "category": category,
                    "document_type": document_type,
                    "chunk_id": f"{source.replace('/', '_')}_{len(chunks) + 1:04d}",
                }
            )
        if end >= len(normalized):
            break
        start = max(start + 1, end - overlap)
    return chunks
