from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any, List

from app.config import BASE_DIR, LOGS_DIR


class DatabaseManager:
    def __init__(self, db_path: str | Path | None = None) -> None:
        self.db_path = Path(db_path) if db_path else BASE_DIR / "analysis.db"
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _init_db(self) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS sessions (
                    session_id TEXT PRIMARY KEY,
                    dataset_path TEXT,
                    user_question TEXT,
                    created_at TEXT,
                    final_report TEXT,
                    status TEXT
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT,
                    agent_name TEXT,
                    start_time TEXT,
                    end_time TEXT,
                    duration REAL,
                    status TEXT,
                    output_summary TEXT,
                    tools_used TEXT,
                    errors TEXT,
                    iteration INTEGER,
                    raw_payload TEXT
                )
                """
            )
            conn.commit()

    def save_session(self, session_id: str, dataset_path: str, user_question: str, final_report: str = "", status: str = "running") -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """
                INSERT INTO sessions (session_id, dataset_path, user_question, created_at, final_report, status)
                VALUES (?, ?, ?, datetime('now'), ?, ?)
                ON CONFLICT(session_id) DO UPDATE SET
                    dataset_path = excluded.dataset_path,
                    user_question = excluded.user_question,
                    final_report = excluded.final_report,
                    status = excluded.status
                """,
                (session_id, dataset_path, user_question, final_report, status),
            )
            conn.commit()

    def log_execution(self, session_id: str, agent_name: str, start_time: str, end_time: str, duration: float, status: str, output_summary: str, tools_used: List[str], errors: List[str], iteration: int, raw_payload: dict | None = None) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """
                INSERT INTO logs (
                    session_id, agent_name, start_time, end_time, duration, status, output_summary, tools_used, errors, iteration, raw_payload
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    session_id,
                    agent_name,
                    start_time,
                    end_time,
                    duration,
                    status,
                    output_summary,
                    json.dumps(tools_used),
                    json.dumps(errors),
                    iteration,
                    json.dumps(raw_payload or {}),
                ),
            )
            conn.commit()

    def write_execution_json(self, session_id: str, trace: dict) -> None:
        session_log_dir = LOGS_DIR / session_id
        session_log_dir.mkdir(parents=True, exist_ok=True)
        (session_log_dir / "execution.json").write_text(json.dumps(trace, indent=2), encoding="utf-8")
