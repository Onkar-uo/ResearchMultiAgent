"""Models and persistent storage."""
