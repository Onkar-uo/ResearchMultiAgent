from __future__ import annotations

from typing import Any, List, Literal, Optional

from pydantic import BaseModel, Field, ConfigDict


class DataProfile(BaseModel):
    model_config = ConfigDict(extra="allow")
    row_count: int = 0
    column_count: int = 0
    numerical_columns: List[str] = Field(default_factory=list)
    categorical_columns: List[str] = Field(default_factory=list)
    datetime_columns: List[str] = Field(default_factory=list)
    missing_columns: dict[str, int] = Field(default_factory=dict)
    duplicate_rows: int = 0
    potential_target: Optional[str] = None
    important_columns: List[str] = Field(default_factory=list)
    summary: str = ""


class CleaningReport(BaseModel):
    model_config = ConfigDict(extra="allow")
    original_rows: int = 0
    final_rows: int = 0
    removed_duplicates: int = 0
    missing_values_handled: int = 0
    outliers_detected: int = 0
    transformations: List[str] = Field(default_factory=list)
    cleaned_dataset_path: str = ""
    notes: str = ""


class StatisticalFinding(BaseModel):
    model_config = ConfigDict(extra="allow")
    metric: str
    description: str
    value: Any = None


class AgentInterpretation(BaseModel):
    model_config = ConfigDict(extra="forbid")
    summary: str = Field(min_length=1, max_length=3000)
    insights: List[str] = Field(default_factory=list, max_length=12)
    limitations: List[str] = Field(default_factory=list, max_length=12)


class StatisticalAnalysis(BaseModel):
    model_config = ConfigDict(extra="allow")
    important_correlations: List[dict[str, Any]] = Field(default_factory=list)
    significant_relationships: List[dict[str, Any]] = Field(default_factory=list)
    group_comparisons: List[dict[str, Any]] = Field(default_factory=list)
    time_trends: List[dict[str, Any]] = Field(default_factory=list)
    statistical_findings: List[StatisticalFinding] = Field(default_factory=list)


class ModelResult(BaseModel):
    name: str
    r2: Optional[float] = None
    rmse: Optional[float] = None
    accuracy: Optional[float] = None


class MLAnalysis(BaseModel):
    model_config = ConfigDict(extra="allow")
    problem_type: str = "regression"
    target: Optional[str] = None
    models: List[ModelResult] = Field(default_factory=list)
    important_features: List[dict[str, Any]] = Field(default_factory=list)
    summary: str = ""


class Hypothesis(BaseModel):
    model_config = ConfigDict(extra="forbid")
    id: str
    statement: str
    evidence_ids: List[str] = Field(default_factory=list, min_length=1)
    domain_sources: List[str] = Field(default_factory=list, max_length=8)
    confidence: float = Field(ge=0.0, le=1.0)
    possible_counter_evidence: List[str] = Field(default_factory=list)


class CriticReview(BaseModel):
    model_config = ConfigDict(extra="forbid")
    overall_status: Literal["PASS", "REVISE", "INSUFFICIENT_EVIDENCE"] = "PASS"
    hypothesis_reviews: List[dict[str, Any]] = Field(default_factory=list)
    missing_evidence: List[str] = Field(default_factory=list)
    contradictions: List[str] = Field(default_factory=list)
    required_additional_analysis: List[str] = Field(default_factory=list)
    confidence: float = Field(default=0.0, ge=0.0, le=1.0)


class HypothesisSet(BaseModel):
    model_config = ConfigDict(extra="forbid")
    hypotheses: List[Hypothesis] = Field(min_length=1, max_length=8)


class ReportFinding(BaseModel):
    model_config = ConfigDict(extra="forbid")
    statement: str = Field(min_length=1, max_length=1000)
    evidence_ids: List[str] = Field(min_length=1)
    domain_sources: List[str] = Field(default_factory=list, max_length=8)


class ReportSections(BaseModel):
    model_config = ConfigDict(extra="forbid")
    executive_summary: str = Field(min_length=1, max_length=3000)
    key_findings: List[ReportFinding] = Field(default_factory=list, max_length=12)
    limitations: List[str] = Field(default_factory=list, max_length=12)


class ExecutionTrace(BaseModel):
    agent_name: str
    status: str
    duration: float
    tools_used: List[str] = Field(default_factory=list)
    output_summary: str = ""
    errors: List[str] = Field(default_factory=list)
    iteration: int = 0
    timestamp: str = ""
