import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent

OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "qwen3:8b")
OLLAMA_EMBEDDING_MODEL = os.getenv("OLLAMA_EMBEDDING_MODEL", "nomic-embed-text")
TEMPERATURE = float(os.getenv("TEMPERATURE", "0.1"))
MAX_ANALYSIS_ITERATIONS = max(0, int(os.getenv("MAX_ANALYSIS_ITERATIONS", "3")))
MAX_FILE_SIZE_MB = max(1, int(os.getenv("MAX_FILE_SIZE_MB", "50")))
RAG_TOP_K = max(1, int(os.getenv("RAG_TOP_K", "5")))
RAG_SIMILARITY_THRESHOLD = min(1.0, max(-1.0, float(os.getenv("RAG_SIMILARITY_THRESHOLD", "0.25"))))
MCP_ENABLED = os.getenv("MCP_ENABLED", "true").strip().lower() in {"true", "1", "yes"}
UPLOAD_DIR = BASE_DIR / os.getenv("UPLOAD_DIR", "data/uploads")
PROCESSED_DIR = BASE_DIR / os.getenv("PROCESSED_DIR", "data/processed")
ARTIFACTS_DIR = BASE_DIR / os.getenv("ARTIFACTS_DIR", "artifacts")
LOGS_DIR = BASE_DIR / os.getenv("LOGS_DIR", "logs")
VECTOR_DB_PATH = BASE_DIR / os.getenv("VECTOR_DB_PATH", "data/vectorstore/knowledge.sqlite3")
KNOWLEDGE_DIR = BASE_DIR / "knowledge"

UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
ARTIFACTS_DIR.mkdir(parents=True, exist_ok=True)
LOGS_DIR.mkdir(parents=True, exist_ok=True)
VECTOR_DB_PATH.parent.mkdir(parents=True, exist_ok=True)
