from __future__ import annotations

from typing import Any

from fastapi import FastAPI, HTTPException, Response
from pydantic import BaseModel

from app.services.analysis_service import run_analysis
from app.mcp.common.config import MCPInputError

app = FastAPI(title="AI Data Science Team")


class AnalysisRequest(BaseModel):
    dataset_path: str
    user_question: str


@app.get("/")
def root() -> dict[str, str]:
    return {
        "name": app.title,
        "status": "ok",
        "docs": "/docs",
        "health": "/health",
        "analyze": "POST /analyze",
        "streamlit_ui": "Run `streamlit run app/ui/streamlit_app.py` for the web interface.",
    }


@app.get("/favicon.ico", include_in_schema=False)
def favicon() -> Response:
    return Response(status_code=204)


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/analyze")
def analyze(request: AnalysisRequest) -> dict[str, Any]:
    try:
        result = run_analysis(request.dataset_path, request.user_question)
    except (MCPInputError, FileNotFoundError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"session_id": result.get("session_id"), "final_report": result.get("final_report"), "state": result}
