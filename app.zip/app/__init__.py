"""AI data science team application package."""
