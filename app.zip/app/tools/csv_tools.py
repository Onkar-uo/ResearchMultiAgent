from __future__ import annotations

import os
import uuid
from pathlib import Path

import pandas as pd

from app.config import PROCESSED_DIR, UPLOAD_DIR


def read_csv_file(path: str | Path) -> pd.DataFrame:
    return pd.read_csv(path)


def safe_copy_upload(upload_path: str | Path, session_id: str | None = None) -> str:
    source = Path(upload_path)
    if not source.exists():
        raise FileNotFoundError(f"Dataset does not exist: {source}")

    safe_name = f"{session_id or uuid.uuid4().hex}_{source.name}"
    target = PROCESSED_DIR / safe_name
    target.write_bytes(source.read_bytes())
    return str(target)


def ensure_safe_filename(filename: str) -> str:
    return "".join(ch if ch.isalnum() or ch in {"_", "-", "."} else "_" for ch in filename)
