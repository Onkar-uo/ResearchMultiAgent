from __future__ import annotations

from pathlib import Path

import pandas as pd


def clean_dataset(path: str | Path, operations: list[str] | None = None) -> dict:
    df = pd.read_csv(path)
    original_rows = len(df)
    missing_values_handled = int(df.isna().sum().sum())
    operations = operations or ["missing_values", "duplicates", "datetime", "outliers"]

    outlier_count = 0
    if "duplicates" in operations:
        df = df.drop_duplicates().copy()
    if "datetime" in operations:
        for col in df.columns:
            if "date" in col.lower() or "time" in col.lower():
                try:
                    df[col] = pd.to_datetime(df[col], format="mixed", errors="coerce")
                except Exception:
                    pass
    if "missing_values" in operations:
        for col in df.columns:
            if pd.api.types.is_numeric_dtype(df[col]):
                median = df[col].median()
                df[col] = df[col].fillna(median)
            else:
                mode = df[col].mode(dropna=True)
                if not mode.empty:
                    df[col] = df[col].fillna(mode.iloc[0])
    if "outliers" in operations:
        for col in df.select_dtypes(include="number").columns:
            q1 = df[col].quantile(0.25)
            q3 = df[col].quantile(0.75)
            iqr = q3 - q1
            lower = q1 - 1.5 * iqr
            upper = q3 + 1.5 * iqr
            outlier_count += int(((df[col] < lower) | (df[col] > upper)).sum())

    cleaned_path = Path(path).with_name(f"cleaned_{Path(path).name}")
    df.to_csv(cleaned_path, index=False)

    return {
        "original_rows": original_rows,
        "final_rows": int(len(df)),
        "removed_duplicates": int(original_rows - len(df)),
        "missing_values_handled": missing_values_handled,
        "missing_values_remaining": int(df.isna().sum().sum()),
        "outliers_detected": outlier_count,
        "transformations": operations,
        "cleaned_dataset_path": str(cleaned_path),
        "notes": "Imputed missing values, removed duplicate rows, converted date-like columns, and detected outliers without removing them.",
    }
