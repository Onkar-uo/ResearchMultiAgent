from __future__ import annotations

from pathlib import Path
from typing import Any

import pandas as pd


def profile_dataset(path: str | Path) -> dict[str, Any]:
    df = pd.read_csv(path)
    numerical_columns = [col for col in df.columns if pd.api.types.is_numeric_dtype(df[col])]
    datetime_columns = []
    for col in df.columns:
        series = df[col]
        if pd.api.types.is_datetime64_any_dtype(series):
            datetime_columns.append(col)
        elif (
            any(token in str(col).lower() for token in ("date", "time", "timestamp"))
            and not pd.api.types.is_numeric_dtype(series)
        ):
            parsed = pd.to_datetime(series, format="mixed", errors="coerce")
            if parsed.notna().mean() >= 0.8:
                datetime_columns.append(col)
    categorical_columns = [
        col
        for col in df.columns
        if col not in datetime_columns
        and df[col].nunique() <= min(20, max(5, len(df) // 10))
        and not pd.api.types.is_numeric_dtype(df[col])
    ]
    missing_columns = {col: int(df[col].isna().sum()) for col in df.columns if df[col].isna().sum() > 0}
    duplicate_rows = int(df.duplicated().sum())
    constant_columns = [col for col in df.columns if df[col].nunique(dropna=True) <= 1]
    suspicious_columns = []
    for col in df.columns:
        if df[col].isna().mean() > 0.3:
            suspicious_columns.append(col)
        elif df[col].nunique(dropna=True) > max(100, len(df) * 0.5):
            suspicious_columns.append(col)

    potential_target = None
    for col in numerical_columns:
        if "sales" in col.lower() or "revenue" in col.lower() or "profit" in col.lower() or "target" in col.lower():
            potential_target = col
            break

    important_columns = [col for col in ["date", "region", "product", "sales", "quantity", "price", "discount", "marketing_spend", "customer_count", "profit"] if col in df.columns]

    summary_parts = [
        f"Dataset contains {len(df)} rows and {len(df.columns)} columns.",
        f"Numerical features: {', '.join(numerical_columns[:10]) if numerical_columns else 'none'}.",
        f"Categorical features: {', '.join(categorical_columns[:10]) if categorical_columns else 'none'}.",
        f"Datetime features: {', '.join(datetime_columns) if datetime_columns else 'none'}.",
    ]
    return {
        "row_count": int(len(df)),
        "column_count": int(len(df.columns)),
        "numerical_columns": numerical_columns,
        "categorical_columns": categorical_columns,
        "datetime_columns": datetime_columns,
        "missing_columns": missing_columns,
        "duplicate_rows": duplicate_rows,
        "constant_columns": constant_columns,
        "suspicious_columns": suspicious_columns,
        "potential_target": potential_target,
        "important_columns": important_columns,
        "summary": " ".join(summary_parts),
    }
