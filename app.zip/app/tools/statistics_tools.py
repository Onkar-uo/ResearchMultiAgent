from __future__ import annotations

from typing import Any

import pandas as pd


def calculate_correlations(df: pd.DataFrame, target: str | None = None) -> dict[str, Any]:
    numeric = df.select_dtypes(include="number")
    corr = numeric.corr(method="pearson")
    if target:
        if target not in corr.columns:
            raise ValueError(f"Target column '{target}' is not numeric.")
        series = corr[target].drop(labels=[target], errors="ignore").dropna()
        ordering = series.reindex(series.abs().sort_values(ascending=False).index)
        top = [
            {
                "feature_a": feature,
                "feature_b": target,
                "correlation": round(float(value), 4),
            }
            for feature, value in ordering.head(10).items()
        ]
    else:
        pairs = [
            (feature_a, feature_b, corr.loc[feature_a, feature_b])
            for index, feature_a in enumerate(corr.columns)
            for feature_b in corr.columns[index + 1 :]
            if pd.notna(corr.loc[feature_a, feature_b])
        ]
        pairs.sort(key=lambda item: abs(item[2]), reverse=True)
        top = [
            {
                "feature_a": feature_a,
                "feature_b": feature_b,
                "correlation": round(float(value), 4),
            }
            for feature_a, feature_b, value in pairs[:10]
        ]
    return {"pearson_top": top}


def group_analysis(df: pd.DataFrame, grouping_col: str, value_col: str) -> list[dict[str, Any]]:
    grouped = df.groupby(grouping_col, dropna=False)[value_col].mean().sort_values(ascending=False)
    result = []
    for key, value in grouped.items():
        result.append({"group": str(key), "avg": round(float(value), 4)})
    return result


def time_trend_analysis(df: pd.DataFrame, date_col: str, value_col: str) -> list[dict[str, Any]]:
    temp = df[[date_col, value_col]].copy()
    temp[date_col] = pd.to_datetime(temp[date_col], format="mixed", errors="coerce")
    temp = temp.dropna(subset=[date_col, value_col])
    if temp.empty:
        return []
    temp = temp.set_index(date_col).resample("MS").mean().reset_index()
    return [{"date": str(row[date_col].date()), "value": round(float(row[value_col]), 4)} for _, row in temp.iterrows()]
