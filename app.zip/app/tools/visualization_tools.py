from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns


def create_plot_directory(session_id: str) -> Path:
    folder = Path("artifacts") / session_id / "plots"
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def generate_time_series_plot(df: pd.DataFrame, date_col: str, value_col: str, session_id: str) -> dict:
    folder = create_plot_directory(session_id)
    temp = df[[date_col, value_col]].copy()
    temp[date_col] = pd.to_datetime(temp[date_col], format="mixed", errors="coerce")
    temp = temp.dropna()
    if temp.empty:
        return {"type": "line_chart", "path": "", "title": "Time series unavailable"}
    plot_path = folder / f"{value_col}_trend.png"
    temp.set_index(date_col)[value_col].plot(figsize=(8, 4), title=f"{value_col} over time")
    plt.tight_layout()
    plt.savefig(plot_path)
    plt.close()
    return {"type": "line_chart", "path": str(plot_path), "title": f"{value_col} over time"}


def generate_correlation_heatmap(df: pd.DataFrame, session_id: str) -> dict:
    folder = create_plot_directory(session_id)
    numeric = df.select_dtypes(include="number")
    if numeric.empty:
        return {"type": "heatmap", "path": "", "title": "No numeric data"}
    plot_path = folder / "correlation_heatmap.png"
    plt.figure(figsize=(8, 6))
    sns.heatmap(numeric.corr(), annot=False, cmap="coolwarm")
    plt.title("Correlation Heatmap")
    plt.tight_layout()
    plt.savefig(plot_path)
    plt.close()
    return {"type": "heatmap", "path": str(plot_path), "title": "Correlation Heatmap"}


def generate_bar_plot(df: pd.DataFrame, group_col: str, value_col: str, session_id: str) -> dict:
    folder = create_plot_directory(session_id)
    plot_path = folder / f"{group_col}_{value_col}_bar.png"
    agg = df.groupby(group_col, dropna=False)[value_col].mean().sort_values(ascending=False)
    agg.plot(kind="bar", figsize=(8, 4), title=f"{value_col} by {group_col}")
    plt.tight_layout()
    plt.savefig(plot_path)
    plt.close()
    return {"type": "bar_chart", "path": str(plot_path), "title": f"{value_col} by {group_col}"}
