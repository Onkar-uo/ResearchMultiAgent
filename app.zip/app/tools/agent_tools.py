from __future__ import annotations

from pathlib import Path
from typing import Any, Callable

import pandas as pd
from pydantic import BaseModel, ConfigDict, ValidationError

from app.tools.statistics_tools import calculate_correlations, group_analysis, time_trend_analysis


class CorrelationArguments(BaseModel):
    model_config = ConfigDict(extra="forbid")
    target: str | None = None


class GroupArguments(BaseModel):
    model_config = ConfigDict(extra="forbid")
    group_column: str
    value_column: str


class TrendArguments(BaseModel):
    model_config = ConfigDict(extra="forbid")
    date_column: str
    value_column: str


TOOL_SCHEMAS = [
    {
        "type": "function",
        "function": {
            "name": "calculate_correlations",
            "description": "Calculate Pearson correlations for numeric features, optionally ordered by a target column.",
            "parameters": CorrelationArguments.model_json_schema(),
        },
    },
    {
        "type": "function",
        "function": {
            "name": "compare_groups",
            "description": "Compare the mean of a numeric column across categories in a grouping column.",
            "parameters": GroupArguments.model_json_schema(),
        },
    },
    {
        "type": "function",
        "function": {
            "name": "analyze_time_trend",
            "description": "Aggregate a numeric value by month using a datetime column.",
            "parameters": TrendArguments.model_json_schema(),
        },
    },
]


def execute_analysis_tool(name: str, arguments: dict[str, Any], dataset_path: str | Path) -> dict[str, Any]:
    df = pd.read_csv(dataset_path)
    implementations: dict[str, tuple[type[BaseModel], Callable[..., Any]]] = {
        "calculate_correlations": (CorrelationArguments, lambda args: calculate_correlations(df, args.target)),
        "compare_groups": (GroupArguments, lambda args: group_analysis(df, args.group_column, args.value_column)),
        "analyze_time_trend": (TrendArguments, lambda args: time_trend_analysis(df, args.date_column, args.value_column)),
    }
    if name not in implementations:
        raise ValueError(f"Tool '{name}' is not available.")

    argument_model, implementation = implementations[name]
    try:
        validated_arguments = argument_model.model_validate(arguments, strict=True)
    except ValidationError as exc:
        raise ValueError(f"Invalid arguments for '{name}': {exc}") from exc

    fields = validated_arguments.model_dump()
    for field_name, value in fields.items():
        if value is not None and value not in df.columns:
            raise ValueError(f"Column '{value}' was not found in the dataset.")
        if field_name == "value_column" and value is not None and not pd.api.types.is_numeric_dtype(df[value]):
            raise ValueError(f"Value column '{value}' must be numeric.")
        if field_name == "target" and value is not None and not pd.api.types.is_numeric_dtype(df[value]):
            raise ValueError(f"Target column '{value}' must be numeric.")
        if field_name == "date_column" and value is not None:
            parsed_dates = pd.to_datetime(df[value], errors="coerce")
            if parsed_dates.notna().sum() == 0:
                raise ValueError(f"Date column '{value}' does not contain parseable dates.")

    return {"tool": name, "arguments": fields, "result": implementation(validated_arguments)}
