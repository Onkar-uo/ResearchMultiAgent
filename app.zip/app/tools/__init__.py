"""Deterministic Python analysis tools."""
