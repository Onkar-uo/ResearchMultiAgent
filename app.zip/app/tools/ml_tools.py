from __future__ import annotations

from typing import Any

import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.feature_selection import SelectKBest, f_regression
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import train_test_split


def infer_problem_type(df: pd.DataFrame, target: str | None = None) -> str:
    if target is None:
        for candidate in ["sales", "profit", "revenue", "target"]:
            if candidate in df.columns:
                target = candidate
                break
    if target and df[target].nunique() <= 10:
        return "classification"
    return "regression"


def train_regression_model(df: pd.DataFrame, target: str, feature_columns: list[str] | None = None) -> dict[str, Any]:
    model_df = df.copy()
    if feature_columns is None:
        feature_columns = [col for col in model_df.columns if col != target and pd.api.types.is_numeric_dtype(model_df[col])]
    X = model_df[feature_columns].fillna(model_df[feature_columns].median())
    y = model_df[target].fillna(model_df[target].median())
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    model = RandomForestRegressor(n_estimators=200, random_state=42)
    selector = SelectKBest(score_func=f_regression, k=min(5, X_train.shape[1]))
    X_train_sel = selector.fit_transform(X_train, y_train)
    X_test_sel = selector.transform(X_test)
    model.fit(X_train_sel, y_train)
    preds = model.predict(X_test_sel)
    metrics = {
        "name": "RandomForestRegressor",
        "r2": r2_score(y_test, preds),
        "rmse": float(__import__('numpy').sqrt(mean_squared_error(y_test, preds))),
    }
    feature_importance = []
    selected_features = [feature_columns[i] for i in selector.get_support(indices=True)]
    for feature, importance in zip(selected_features, model.feature_importances_):
        feature_importance.append({"feature": feature, "importance": round(float(importance), 4)})
    return {
        "problem_type": "regression",
        "target": target,
        "models": [metrics],
        "important_features": sorted(feature_importance, key=lambda item: item["importance"], reverse=True),
        "summary": f"Regressed {target} using a RandomForest model with R² {metrics['r2']:.3f} and RMSE {metrics['rmse']:.2f}.",
    }
