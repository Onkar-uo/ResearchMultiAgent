from __future__ import annotations

import json
import re
import uuid
from pathlib import Path
from typing import Any

import pandas as pd
import requests
import streamlit as st

from app.config import (
    KNOWLEDGE_DIR,
    MAX_FILE_SIZE_MB,
    MCP_ENABLED,
    OLLAMA_BASE_URL,
    OLLAMA_EMBEDDING_MODEL,
    OLLAMA_MODEL,
    UPLOAD_DIR,
)


@st.cache_data(ttl=30)
def _ollama_status() -> tuple[bool, list[str], str | None]:
    try:
        response = requests.get(f"{OLLAMA_BASE_URL.rstrip('/')}/api/tags", timeout=2)
        response.raise_for_status()
        models = [item.get("name", "") for item in response.json().get("models", [])]
        return True, models, None
    except (requests.RequestException, ValueError) as exc:
        return False, [], str(exc)


def render_knowledge_and_tools() -> None:
    from app.mcp.registry import list_mcp_registry
    from app.rag.service import RAGService

    st.header("Local knowledge base and MCP tools")
    available, models, error = _ollama_status()
    status_cols = st.columns(3)
    status_cols[0].metric("Ollama", "Available" if available else "Unavailable")
    status_cols[1].metric("LLM", "Installed" if OLLAMA_MODEL in models else "Not found")
    status_cols[2].metric(
        "Embedding model",
        "Installed" if OLLAMA_EMBEDDING_MODEL in models else "Not found",
    )
    if error:
        st.warning(f"Ollama status check failed: {error}")

    service = RAGService()
    sources = service.list_sources()
    st.metric("Indexed knowledge sources", len(sources))
    uploaded_dir = KNOWLEDGE_DIR / "uploaded"
    uploaded_dir.mkdir(parents=True, exist_ok=True)
    uploaded = st.file_uploader("Add a local knowledge document", type=["md", "txt", "pdf"])
    if uploaded is not None:
        if uploaded.size > MAX_FILE_SIZE_MB * 1024 * 1024:
            st.error(f"Document exceeds the {MAX_FILE_SIZE_MB} MB limit.")
        else:
            safe_stem = re.sub(r"[^A-Za-z0-9_-]+", "_", Path(uploaded.name).stem)[:60] or "document"
            destination = uploaded_dir / f"{uuid.uuid4().hex}_{safe_stem}{Path(uploaded.name).suffix.lower()}"
            if st.button("Save document to local knowledge base"):
                destination.write_bytes(uploaded.getvalue())
                st.success(f"Saved `{destination.name}`. Re-index the knowledge base to use it.")
    if st.button("Index / refresh local knowledge"):
        try:
            with st.spinner("Embedding local knowledge with Ollama..."):
                result = service.ingest()
            st.success(
                f"Scanned {result['documents_seen']} documents; added {result['chunks_added']} chunks "
                f"({result['indexed_chunks']} indexed total)."
            )
            if result["errors"]:
                st.warning(result["errors"])
            sources = service.list_sources()
        except Exception as exc:
            st.error(f"Knowledge indexing failed: {exc}")
    if sources:
        st.dataframe(pd.DataFrame(sources), hide_index=True, use_container_width=True)

    st.subheader("MCP server and tool catalog")
    st.caption(
        "MCP calls use embedded local FastMCP servers through LangChain. "
        f"MCP is {'enabled' if MCP_ENABLED else 'disabled'}; local Python fallbacks remain available."
    )
    registry = list_mcp_registry()
    st.dataframe(
        pd.DataFrame(
            [
                {
                    "Server": item["server"],
                    "Tool": item.get("tool") or "—",
                    "Status": item["status"],
                    "Description": item.get("description", ""),
                }
                for item in registry
            ]
        ),
        hide_index=True,
        use_container_width=True,
    )


def render_metrics(state: dict[str, Any]) -> None:
    profile = state.get("data_profile", {})
    cleaning = state.get("cleaning_report", {})
    total_missing = sum(profile.get("missing_columns", {}).values())
    columns = st.columns(4)
    columns[0].metric("Rows", f"{profile.get('row_count', 0):,}")
    columns[1].metric("Columns", profile.get("column_count", 0))
    columns[2].metric("Missing values", f"{total_missing:,}")
    columns[3].metric("Duplicates removed", f"{cleaning.get('removed_duplicates', 0):,}")


def render_visualizations(state: dict[str, Any]) -> None:
    visuals = state.get("visualizations", [])
    if not visuals:
        st.info("No charts were produced for this dataset.")
        return

    columns = st.columns(2)
    for index, visual in enumerate(visuals):
        path = visual.get("path")
        with columns[index % 2]:
            st.markdown(f"**{visual.get('title', visual.get('type', 'Chart'))}**")
            if path and Path(path).is_file():
                st.image(path, use_container_width=True)
            else:
                st.caption("Chart image is unavailable.")
            if visual.get("reason"):
                st.caption(visual["reason"])


def render_trace(state: dict[str, Any]) -> None:
    with st.expander("Agent execution trace", expanded=False):
        for record in state.get("execution_trace", []):
            title = (
                f"{record.get('agent_name', 'Agent')} · {record.get('status', 'unknown')} · "
                f"{record.get('duration', 0):.2f}s"
            )
            st.markdown(f"**{title}**")
            st.caption(record.get("output_summary", ""))
            if record.get("tools_used"):
                st.write("Tools: " + ", ".join(record["tools_used"]))
            if record.get("errors"):
                for error in record["errors"]:
                    st.warning(error)
        st.caption(
            f"Critic status: {state.get('critic_review', {}).get('overall_status', 'not run')} · "
            f"Feedback iterations: {state.get('iteration', 0)} / {state.get('max_iterations', 0)}"
        )
        for error in state.get("errors", []):
            st.error(f"{error.get('agent', 'Agent')}: {error.get('error', 'Unknown error')}")


def render_dashboard(state: dict[str, Any]) -> None:
    st.header("Analysis dashboard")
    render_metrics(state)

    profile_tab, findings_tab, model_tab, charts_tab, knowledge_tab, trace_tab = st.tabs(
        ["Dataset", "Findings", "ML results", "Visualizations", "Knowledge & MCP", "Agent trace"]
    )
    with profile_tab:
        profile = state.get("data_profile", {})
        st.write(state.get("profile_interpretation", {}).get("summary", profile.get("summary", "")))
        if profile.get("important_columns"):
            st.write("Important columns:", ", ".join(profile["important_columns"]))
        if profile.get("missing_columns"):
            st.subheader("Missing values by column")
            st.dataframe(
                pd.DataFrame(
                    [{"Column": column, "Missing": count} for column, count in profile["missing_columns"].items()]
                ),
                hide_index=True,
                use_container_width=True,
            )
        st.subheader("Cleaning")
        st.write(state.get("cleaning_interpretation", {}).get("summary", ""))
        st.json(state.get("cleaning_report", {}))

    with findings_tab:
        interpretation = state.get("statistical_interpretation", {})
        if interpretation.get("summary"):
            st.write(interpretation["summary"])
        statistics = state.get("statistical_analysis", {})
        correlations = statistics.get("important_correlations", [])
        if correlations:
            st.subheader("Correlations")
            st.dataframe(pd.DataFrame(correlations), hide_index=True, use_container_width=True)
        groups = statistics.get("group_comparisons", [])
        if groups:
            st.subheader("Group comparisons")
            st.dataframe(pd.DataFrame(groups), hide_index=True, use_container_width=True)
        st.subheader("Hypotheses")
        hypotheses = state.get("hypotheses", [])
        if not hypotheses:
            st.info("No hypotheses passed evidence validation.")
        for hypothesis in hypotheses:
            with st.expander(
                f"{hypothesis.get('id', 'Hypothesis')} · confidence {hypothesis.get('confidence', 0):.0%}"
            ):
                st.write(hypothesis.get("statement", ""))
                st.markdown("**Evidence**")
                for evidence in hypothesis.get("evidence", []):
                    st.write(f"- {evidence}")
                if hypothesis.get("possible_counter_evidence"):
                    st.markdown("**Counter-evidence / limitations**")
                    for item in hypothesis["possible_counter_evidence"]:
                        st.write(f"- {item}")
        st.caption(
            "Critic review: "
            f"{state.get('critic_review', {}).get('overall_status', 'not run')}"
        )

    with model_tab:
        ml = state.get("ml_analysis", {})
        st.write(state.get("ml_interpretation", {}).get("summary", ml.get("summary", "")))
        if ml.get("models"):
            st.dataframe(pd.DataFrame(ml["models"]), hide_index=True, use_container_width=True)
        else:
            st.info("No machine-learning model was trained.")
        if ml.get("important_features"):
            st.subheader("Predictive feature importance")
            st.dataframe(pd.DataFrame(ml["important_features"]), hide_index=True, use_container_width=True)
        st.caption("Feature importance reflects predictive association, not causation.")

    with charts_tab:
        render_visualizations(state)

    with knowledge_tab:
        sources = state.get("rag_sources", [])
        st.subheader("Retrieved domain knowledge")
        if sources:
            for item in sources:
                with st.expander(
                    f"{item['source']} · similarity {item.get('score', 0):.3f}"
                ):
                    st.write(item["content"])
        else:
            st.info("No domain-knowledge chunks were retrieved.")
        st.subheader("MCP tool calls")
        if state.get("mcp_tool_calls"):
            st.dataframe(
                pd.DataFrame(
                    [
                        {
                            "Server": item.get("server"),
                            "Tool": item.get("tool"),
                            "Status": item.get("status"),
                            "Agent": item.get("agent"),
                            "Fallback": item.get("fallback", ""),
                            "Error": item.get("error", ""),
                        }
                        for item in state["mcp_tool_calls"]
                    ]
                ),
                hide_index=True,
                use_container_width=True,
            )
        else:
            st.info("No MCP tools were called.")
        if state.get("knowledge_queries"):
            with st.expander("Knowledge retrieval queries"):
                st.json(state["knowledge_queries"])

    with trace_tab:
        render_trace(state)
        if state.get("tool_results"):
            st.subheader("LLM-selected Python tools")
            st.json(state["tool_results"])

    st.header("Final report")
    report = state.get("final_report", "No report was generated.")
    st.markdown(report)
    first, second = st.columns(2)
    first.download_button(
        "Download report (Markdown)",
        data=report,
        file_name=f"analysis-{state.get('session_id', 'report')}.md",
        mime="text/markdown",
        use_container_width=True,
    )
    second.download_button(
        "Download analysis data (JSON)",
        data=json.dumps(state, ensure_ascii=False, indent=2, default=str),
        file_name=f"analysis-{state.get('session_id', 'report')}.json",
        mime="application/json",
        use_container_width=True,
    )


def main() -> None:
    st.set_page_config(page_title="AI Data Science Team", page_icon="📊", layout="wide")
    st.title("AI Data Science Team")
    st.caption("Local-LLM-guided analysis with deterministic Python tools.")
    page = st.sidebar.radio("Workspace", ["Analysis", "Knowledge & tools"])
    if page == "Knowledge & tools":
        render_knowledge_and_tools()
        return

    with st.form("analysis_form"):
        uploaded_file = st.file_uploader("Upload CSV", type=["csv"])
        question = st.text_area("Analytical question", value="Why are sales declining?")
        submitted = st.form_submit_button("Start analysis", type="primary")

    if submitted:
        if uploaded_file is None:
            st.warning("Please upload a CSV file first.")
        elif not question.strip():
            st.warning("Please enter an analytical question.")
        else:
            st.session_state.pop("analysis_result", None)
            if uploaded_file.size > MAX_FILE_SIZE_MB * 1024 * 1024:
                st.error(f"CSV exceeds the {MAX_FILE_SIZE_MB} MB limit.")
                return
            uploads = UPLOAD_DIR
            uploads.mkdir(parents=True, exist_ok=True)
            safe_stem = re.sub(r"[^A-Za-z0-9_-]+", "_", Path(uploaded_file.name).stem)[:60] or "dataset"
            save_path = uploads / f"{uuid.uuid4().hex}_{safe_stem}.csv"
            save_path.write_bytes(uploaded_file.getvalue())
            try:
                from app.services.analysis_service import run_analysis

                with st.spinner("The agent graph is analyzing the dataset..."):
                    st.session_state["analysis_result"] = run_analysis(save_path, question.strip())
            except Exception as exc:
                st.error(f"Analysis could not be completed: {exc}")

    if st.session_state.get("analysis_result"):
        render_dashboard(st.session_state["analysis_result"])


if __name__ == "__main__":
    main()
